<?php
class Laporan_presensi_pegawai extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		date_default_timezone_set('Asia/Jakarta');
		header('Access-Control-Allow-Origin: *');
	}

	public function print_laporan()
	{
		$json = file_get_contents('php://input');
		$ambil = json_decode($json, true);
		
		if ($ambil['filter'] == 'tanggal') {
			$dari_tanggal = date('d-m-Y', strtotime($ambil['dari_tanggal']));
			$sampai_tanggal = date('d-m-Y', strtotime($ambil['sampai_tanggal']));

			$pegawai_list = $this->db->query("SELECT * FROM pegawai_jabatan ORDER BY id asc")->result_array();
			$grouped_by_tanggal = [];

			$start = strtotime($dari_tanggal);
			$end = strtotime($sampai_tanggal);
			for ($current = $start; $current <= $end; $current = strtotime('+1 day', $current)) {
				$tanggal = date('d-m-Y', $current);
				foreach ($pegawai_list as $pegawai) {
        $presensi = $this->db->query("
            SELECT * FROM presensi_pegawai
            WHERE id_pegawai = ? AND tanggal = ?
        ", [$pegawai['id_pegawai'], $tanggal])->row_array();

        $grouped_by_tanggal[$tanggal][] = [
            'nama_pegawai' => $pegawai['nama_pegawai'],
            'jabatan' => $pegawai['jabatan'],
            'status' => $presensi ? '1' : '0',
            'jam_masuk' => $presensi['waktu'] ?? null,
            'jam_terlambat' => $presensi['jam_terlambat'] ?? null,
            'jam_pulang' => $presensi['jam_pulang'] ?? null,
            'status_absen' => $presensi['status'] ?? null,
        ];
    }
			}
			$data = [
				'judul' => $dari_tanggal . ' s/d ' . $sampai_tanggal,
				'grouped_by_tanggal' => $grouped_by_tanggal,
				'status' => 'Bulan'
			];

		} else if ($ambil['filter'] == 'bulan') {
$bulan = $ambil['filter_bulan'];
$tahun = $ambil['filter_tahun'];
$total_days = cal_days_in_month(CAL_GREGORIAN, $bulan, $tahun);
$pegawai_list = $this->db->query("SELECT * FROM pegawai_jabatan ORDER BY id asc")->result_array();

$grouped_by_tanggal = [];

for ($i = 1; $i <= $total_days; $i++) {
    $hari = sprintf("%02d", $i);
    $tanggal = $hari . '-' . $bulan . '-' . $tahun;

    foreach ($pegawai_list as $pegawai) {
        $presensi = $this->db->query("
            SELECT * FROM presensi_pegawai 
            WHERE id_pegawai = ? AND tanggal = ?
        ", [$pegawai['id_pegawai'], $tanggal])->row_array();

        $grouped_by_tanggal[$tanggal][] = [
            'nama_pegawai' => $pegawai['nama_pegawai'],
            'jabatan' => $pegawai['jabatan'],
            'status' => $presensi ? '1' : '0',
            'jam_masuk' => $presensi['waktu'] ?? null,
            'jam_terlambat' => $presensi['jam_terlambat'] ?? null,
            'jam_pulang' => $presensi['jam_pulang'] ?? null,
            'status_absen' => $presensi['status'] ?? null,
        ];
    }
}

$data = [
    'judul' => $this->getBulan($bulan) . " " . $tahun,
    'grouped_by_tanggal' => $grouped_by_tanggal,
    'status' => 'Bulan'
];

		} else {
			$tahun = $ambil['single_filter_tahun'];
$start = new DateTime("01-01-$tahun");
$end   = new DateTime("31-12-$tahun");
$end->modify('+1 day'); // agar 31-12 ikut
$pegawai_list = $this->db->query("SELECT * FROM pegawai_jabatan ORDER BY id asc")->result_array();
$period = new DatePeriod($start, new DateInterval('P1D'), $end);
$grouped_by_tanggal = [];

foreach ($period as $date) {
	$tanggal = $date->format('d-m-Y');
	foreach ($pegawai_list as $key => $pegawai) {
		$presensi = $this->db->query("SELECT * FROM presensi_pegawai WHERE id_pegawai = ? AND tanggal = ?  ", [$pegawai['id_pegawai'], $tanggal])->row_array();
		$grouped_by_tanggal[$tanggal][] = [
			 'nama_pegawai' => $pegawai['nama_pegawai'],
            'jabatan' => $pegawai['jabatan'],
            'status' => $presensi ? '1' : '0',
            'jam_masuk' => $presensi['waktu'] ?? null,
            'jam_terlambat' => $presensi['jam_terlambat'] ?? null,
            'jam_pulang' => $presensi['jam_pulang'] ?? null,
            'status_absen' => $presensi['status'] ?? null,
		];
	}
}

$data = [
    'judul' => "Presensi Tahun $tahun",
    'grouped_by_tanggal' => $grouped_by_tanggal,
    'status' => 'Tahun'
];
		}
		$this->load->view('admin/data_laporan/laporan_presensi_pegawai', $data);
	}

	public function getBulan($bulan)
	{
		$daftar_bulan = [
			1 => 'Januari',
			2 => 'Februari',
			3 => 'Maret',
			4 => 'April',
			5 => 'Mei',
			6 => 'Juni',
			7 => 'Juli',
			8 => 'Agustus',
			9 => 'September',
			10 => 'Oktober',
			11 => 'November',
			12 => 'Desember',
		];

		return $daftar_bulan[(int) $bulan] ?? 'Bulan tidak valid';
	}

}
