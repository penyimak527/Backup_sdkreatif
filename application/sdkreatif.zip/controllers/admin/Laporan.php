<?php
class Laporan extends CI_Controller
{

	function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		if ($this->session->userdata('admin')['username'] == null) {
			redirect('/');
		}

		$data['title'] = 'Laporan';
		$data['guru'] = $this->db->get('guru')->result_array();
		$this->db->where('jabatan !=', 'Guru');
		$data['pegawai'] = $this->db->get('pegawai_jabatan')->result_array();
		$data['pegawai_all'] = $this->db->get('pegawai')->result_array();
		$data['periode'] = $this->db->get('master_tahun_ajaran')->result_array();
		$data['kelas'] = $this->db->get('kelas')->result_array();
		$data['view'] = $this;
		$this->load->view('template/header', $data);
		$this->load->view('admin/laporan', $data);
		$this->load->view('template/footer');
	}

	public function excel()
	{
		if ($this->session->userdata('admin')['username'] == null) {
			redirect('/');
		}

		$data['title'] = 'Laporan';
		$this->load->view('template/header', $data);
		$this->load->view('admin/data_laporan/excel/laporan_izin_pegawai', $data);
		$this->load->view('template/footer');
	}

	public function laporan_result()
	{
		$id_level = $this->session->userdata('admin')['id_level'];
		$search = $this->input->post('search');

		if ($search != null) {
			$this->db->where('group', 'Laporan');
			$this->db->where('id_level', $id_level);
			$this->db->like('name', $search); // pakai LIKE agar pencarian fleksibel
			$data = $this->db->get('conf_list_menu')->result_array();
		} else {
			$data = $this->db->get_where('conf_list_menu', [
				'group' => 'Laporan',
				'id_level' => $id_level
			])->result_array();
		}
		echo json_encode($data);
	}

	public function laporan_jurnal_pegawai()
	{
		$dari_tanggal = $this->input->post('dari_tanggal');
		$sampai_tanggal = $this->input->post('sampai_tanggal');
		$id_pegawai = $this->input->post('id_pegawai');
		$filter = $this->input->post('filter');

		if ($filter === 'tanggal' && (empty($dari_tanggal) || empty($sampai_tanggal))) {
			echo json_encode([]);
			return;
		}

		if ($filter == 'tanggal') {
			$sql = "
            SELECT a.*
            FROM jurnal_pegawai a
            WHERE STR_TO_DATE(a.tanggal, '%d-%m-%Y')
                  BETWEEN STR_TO_DATE(?, '%Y-%m-%d')
                      AND STR_TO_DATE(?, '%Y-%m-%d')
        ";
			$params = [$dari_tanggal, $sampai_tanggal];

			if ($id_pegawai !== '') {
				$sql .= " AND a.id_pegawai = ? ";
				$params[] = $id_pegawai;
			}

			$sql .= " ORDER BY STR_TO_DATE(a.tanggal, '%d-%m-%Y') ASC";
			$rows = $this->db->query($sql, $params)->result_array();

		} elseif ($filter == 'bulan') {
			$bulan = $this->input->post('bulan');
			$tahun = $this->input->post('tahun');

			$sql = "
            SELECT a.*
            FROM jurnal_pegawai a
            WHERE MONTH(STR_TO_DATE(a.tanggal, '%d-%m-%Y')) = ?
              AND YEAR(STR_TO_DATE(a.tanggal, '%d-%m-%Y')) = ?
        ";
			$params = [$bulan, $tahun];

			if ($id_pegawai !== '') {
				$sql .= " AND a.id_pegawai = ? ";
				$params[] = $id_pegawai;
			}

			$sql .= " ORDER BY STR_TO_DATE(a.tanggal, '%d-%m-%Y') ASC";
			$rows = $this->db->query($sql, $params)->result_array();

		} else { // tahun
			$single_filter_tahun = $this->input->post('single_filter_tahun');

			$sql = "
            SELECT a.*
            FROM jurnal_pegawai a
            WHERE YEAR(STR_TO_DATE(a.tanggal, '%d-%m-%Y')) = ?
        ";
			$params = [$single_filter_tahun];

			if ($id_pegawai !== '') {
				$sql .= " AND a.id_pegawai = ? ";
				$params[] = $id_pegawai;
			}

			$sql .= " ORDER BY STR_TO_DATE(a.tanggal, '%d-%m-%Y') ASC";
			$rows = $this->db->query($sql, $params)->result_array();
		}

		if ($id_pegawai === '') {
			$grouped = [];
			foreach ($rows as $row) {
				$nama_pegawai = $row['nama_pegawai']; // d-m-Y
				if (!isset($grouped[$nama_pegawai]))
					$grouped[$nama_pegawai] = [];
				$grouped[$nama_pegawai][] = $row;
			}
			$data = $grouped;
		} else {
			$data = $rows;
		}



		echo json_encode($data);
	}

	public function laporan_jurnal_guru_kelas()
	{
		$dari_tanggal = date('d-m-Y', strtotime($this->input->post('dari_tanggal')));
		$sampai_tanggal = date('d-m-Y', strtotime($this->input->post('sampai_tanggal')));

		$filter = $this->input->post('filter');
		$id_kelas = $this->input->post('id_kelas');
		$periode = $this->input->post('periode');
		$semester = $this->input->post('semester');
		$bulan = $this->input->post('bulan');
		$tahun = $this->input->post('tahun');
		$single_filter_tahun = $this->input->post('single_filter_tahun');
		if ($filter == 'tanggal') {

			if ($id_kelas == 'Semua') {

				$jurnal_guru = $this->db->query("SELECT a.*,d.nama_kelas,d.kode_kelas FROM jurnal_guru a left join kelas_jadwal_pelajaran b on a.id_kelas_jadwal_pelajaran = b.id
			  left join kelas d on b.id_kelas = d.id
				WHERE STR_TO_DATE(a.tanggal, '%d-%m-%Y') BETWEEN STR_TO_DATE('$dari_tanggal', '%d-%m-%Y') 
				AND STR_TO_DATE('$sampai_tanggal', '%d-%m-%Y') 
				AND a.id_periode = '$periode' 
				AND a.semester = '$semester' Order by a.jam_mulai_pelajaran asc")->result_array();
			} else {
				$jurnal_guru = $this->db->query("SELECT a.*,d.nama_kelas,d.kode_kelas FROM jurnal_guru a left join kelas_jadwal_pelajaran b on a.id_kelas_jadwal_pelajaran = b.id
				 left join kelas d on b.id_kelas = d.id
				WHERE STR_TO_DATE(a.tanggal, '%d-%m-%Y') BETWEEN STR_TO_DATE('$dari_tanggal', '%d-%m-%Y') 
				AND STR_TO_DATE('$sampai_tanggal', '%d-%m-%Y') 
				AND a.id_periode = '$periode' 
				AND b.id_kelas = '$id_kelas' 
				AND a.semester = '$semester' Order by a.jam_mulai_pelajaran asc")->result_array();
			}
			$grouped_by_guru_mapel = [];


			foreach ($jurnal_guru as $row) {
				$nama_guru = $row['nama_guru'];
				$mapel = $row['mapel'];
				if (!isset($grouped_by_guru_mapel[$nama_guru])) {
					$grouped_by_guru_mapel[$nama_guru] = [];
				}
				if (!isset($grouped_by_guru_mapel[$nama_guru][$mapel])) {
					$grouped_by_guru_mapel[$nama_guru][$mapel] = [];
				}
				$grouped_by_guru_mapel[$nama_guru][$mapel][] = $row;
			}
			$data = $grouped_by_guru_mapel;


		} else if ($filter == 'bulan') {


			if ($id_kelas == 'Semua') {

				$jurnal_guru = $this->db->query("SELECT a.*,d.nama_kelas,d.kode_kelas FROM jurnal_guru a left join kelas_jadwal_pelajaran b on a.id_kelas_jadwal_pelajaran = b.id
		  left join kelas d on b.id_kelas = d.id
			WHERE MONTH(STR_TO_DATE(a.tanggal, '%d-%m-%Y')) = '$bulan' AND YEAR(STR_TO_DATE(a.tanggal, '%d-%m-%Y')) = '$tahun'  
			AND a.id_periode = '$periode' 
			AND a.semester = '$semester' Order by a.jam_mulai_pelajaran asc")->result_array();
			} else {
				$jurnal_guru = $this->db->query("SELECT a.*,d.nama_kelas,d.kode_kelas FROM jurnal_guru a left join kelas_jadwal_pelajaran b on a.id_kelas_jadwal_pelajaran = b.id
			 left join kelas d on b.id_kelas = d.id
			WHERE MONTH(STR_TO_DATE(a.tanggal, '%d-%m-%Y')) = '$bulan' AND YEAR(STR_TO_DATE(a.tanggal, '%d-%m-%Y')) = '$tahun'   
			AND a.id_periode = '$periode' 
			AND b.id_kelas = '$id_kelas' 
			AND a.semester = '$semester' Order by a.jam_mulai_pelajaran asc")->result_array();
			}
			$grouped_by_guru_mapel = [];

			foreach ($jurnal_guru as $row) {
				$nama_guru = $row['nama_guru'];
				$mapel = $row['mapel'];
				if (!isset($grouped_by_guru_mapel[$nama_guru])) {
					$grouped_by_guru_mapel[$nama_guru] = [];
				}
				if (!isset($grouped_by_guru_mapel[$nama_guru][$mapel])) {
					$grouped_by_guru_mapel[$nama_guru][$mapel] = [];
				}
				$grouped_by_guru_mapel[$nama_guru][$mapel][] = $row;
			}
			$data = $grouped_by_guru_mapel;
		} else {

			if ($id_kelas == 'Semua') {

				$jurnal_guru = $this->db->query("SELECT a.*,d.nama_kelas,d.kode_kelas FROM jurnal_guru a left join kelas_jadwal_pelajaran b on a.id_kelas_jadwal_pelajaran = b.id
		  left join kelas d on b.id_kelas = d.id
			WHERE YEAR(STR_TO_DATE(a.tanggal, '%d-%m-%Y')) = '$single_filter_tahun'  
			AND a.id_periode = '$periode' 
			AND a.semester = '$semester' Order by a.jam_mulai_pelajaran asc")->result_array();
			} else {
				$jurnal_guru = $this->db->query("SELECT a.*,d.nama_kelas,d.kode_kelas FROM jurnal_guru a left join kelas_jadwal_pelajaran b on a.id_kelas_jadwal_pelajaran = b.id
			 left join kelas d on b.id_kelas = d.id
			WHERE YEAR(STR_TO_DATE(a.tanggal, '%d-%m-%Y')) = '$single_filter_tahun'   
			AND a.id_periode = '$periode' 
			AND b.id_kelas = '$id_kelas' 
			AND a.semester = '$semester' Order by a.jam_mulai_pelajaran asc")->result_array();
			}
			$grouped_by_guru_mapel = [];

			foreach ($jurnal_guru as $row) {
				$nama_guru = $row['nama_guru'];
				$mapel = $row['mapel'];
				if (!isset($grouped_by_guru_mapel[$nama_guru])) {
					$grouped_by_guru_mapel[$nama_guru] = [];
				}
				if (!isset($grouped_by_guru_mapel[$nama_guru][$mapel])) {
					$grouped_by_guru_mapel[$nama_guru][$mapel] = [];
				}
				$grouped_by_guru_mapel[$nama_guru][$mapel][] = $row;
			}
			$data = $grouped_by_guru_mapel;
		}
		echo json_encode($data);
	}

public function laporan_resume_tanggal_kegiatan_belum_diisi()
{
    // --- Ambil input ---
    $dari_tanggal        = $this->input->post('dari_tanggal') ? date('d-m-Y', strtotime($this->input->post('dari_tanggal'))) : null;
    $sampai_tanggal      = $this->input->post('sampai_tanggal') ? date('d-m-Y', strtotime($this->input->post('sampai_tanggal'))) : null;
    $filter              = $this->input->post('filter');           
    $periode             = $this->input->post('periode');          
    $semester            = $this->input->post('semester');          
    $bulan               = $this->input->post('bulan');
    $tahun               = $this->input->post('tahun');
    $single_filter_tahun = $this->input->post('single_filter_tahun');

    // --- Master pegawai (non-Guru) ---
    $sqlPegawai = "
        SELECT a.nama_pegawai
        FROM pegawai a
        LEFT JOIN pegawai_jabatan b ON a.id = b.id_pegawai
        WHERE (b.jabatan IS NULL OR b.jabatan <> 'Guru')
    ";
    $pegRows = $this->db->query($sqlPegawai)->result_array();
    $daftarPegawai = array_map(fn($x) => trim($x['nama_pegawai']), $pegRows);

    // --- Bangun allDates sesuai filter ---
    $allDates = [];
    if ($filter === 'tanggal' && $dari_tanggal && $sampai_tanggal) {
        $start = DateTime::createFromFormat('d-m-Y', $dari_tanggal);
        $end   = DateTime::createFromFormat('d-m-Y', $sampai_tanggal);
        if ($start && $end && $start <= $end) {
            $endInc = (clone $end)->modify('+1 day');
            $period = new DatePeriod($start, new DateInterval('P1D'), $endInc);
            foreach ($period as $dt) $allDates[] = $dt->format('d-m-Y');
        }
        $periode_label = $dari_tanggal . ' s.d. ' . $sampai_tanggal;
    } elseif ($filter === 'bulan' && $bulan && $tahun) {
        $hari = cal_days_in_month(CAL_GREGORIAN, (int)$bulan, (int)$tahun);
        for ($d = 1; $d <= $hari; $d++) $allDates[] = sprintf('%02d-%02d-%04d', $d, $bulan, $tahun);
        $periode_label = sprintf('%02d-%04d', $bulan, $tahun);
    } else {
        $th = (int)($single_filter_tahun ?: $tahun);
        for ($m = 1; $m <= 12; $m++) {
            $hari = cal_days_in_month(CAL_GREGORIAN, $m, $th);
            for ($d = 1; $d <= $hari; $d++) $allDates[] = sprintf('%02d-%02d-%04d', $d, $m, $th);
        }
        $periode_label = (string)$th;
    }

    if (empty($allDates)) {
        echo json_encode(['data' => new stdClass(), 'meta' => ['kelas' => '-', 'semester' => ($semester ?: '-'), 'periode' => ($periode_label ?: '-')]]);
        return;
    }
 
    $params = [];
    $where  = [];

    if ($filter === 'tanggal' && $dari_tanggal && $sampai_tanggal) {
        $where[]  = "STR_TO_DATE(COALESCE(a.tanggal_input, a.tanggal), '%d-%m-%Y') BETWEEN STR_TO_DATE(?, '%d-%m-%Y') AND STR_TO_DATE(?, '%d-%m-%Y')";
        $params[] = $dari_tanggal;
        $params[] = $sampai_tanggal;
    } elseif ($filter === 'bulan' && $bulan && $tahun) {
        $where[]  = "MONTH(STR_TO_DATE(COALESCE(a.tanggal_input, a.tanggal), '%d-%m-%Y')) = ?";
        $where[]  = "YEAR(STR_TO_DATE(COALESCE(a.tanggal_input, a.tanggal), '%d-%m-%Y')) = ?";
        $params[] = $bulan;
        $params[] = $tahun;
    } else {
        $th = (int)($single_filter_tahun ?: $tahun);
        $where[]  = "YEAR(STR_TO_DATE(COALESCE(a.tanggal_input, a.tanggal), '%d-%m-%Y')) = ?";
        $params[] = $th;
    }

    // jika perlu filter periode/semester dari kolom jurnal_pegawai, aktifkan baris berikut:
    if (!empty($periode))  { $where[] = "a.periode = ?";  $params[] = $periode; }
    if (!empty($semester)) { $where[] = "a.semester = ?"; $params[] = $semester; }

    $sqlRows = "
        SELECT a.nama_pegawai,
               a.tanggal_input,
               a.tanggal,
               a.semester,
               a.periode
        FROM jurnal_pegawai a
        " . (empty($where) ? "" : "WHERE " . implode(" AND ", $where)) . "
        ORDER BY STR_TO_DATE(COALESCE(a.tanggal_input, a.tanggal), '%d-%m-%Y') ASC
    ";
    $rows = $this->db->query($sqlRows, $params)->result_array();

    // --- Tandai tanggal yang sudah diisi per pegawai ---
    $filled = []; // [nama_pegawai => ['dd-mm-YYYY' => true]]
    $meta   = []; // [nama_pegawai => ['semester'=>'..','periode'=>'..']]
    foreach ($rows as $r) {
        $raw = $r['tanggal_input'] ?: $r['tanggal'];
        if (!$raw) continue;
        $dt = DateTime::createFromFormat('d-m-Y', trim($raw));
        if (!$dt) continue;

        $tgl  = $dt->format('d-m-Y');
        $nama = trim($r['nama_pegawai']);
        if ($nama === '') continue;

        $filled[$nama][$tgl] = true;
        // simpan meta sederhana (boleh diubah ke "pertama" atau "terakhir")
        $meta[$nama]['semester'] = $r['semester'] ?? ($semester ?: '-');
        $meta[$nama]['periode']  = $r['periode']  ?? $periode_label;
    }
 
    $missing = [];  
    $semester_label = $semester ?: '-';

    foreach ($daftarPegawai as $nama) {
        $nama   = trim($nama);
        $sudah  = isset($filled[$nama]) ? array_keys($filled[$nama]) : [];
        $kosong = array_values(array_diff($allDates, $sudah));
        sort($kosong);

        if (!empty($kosong)) { // tampilkan HANYA yang masih punya kekosongan
            $missing[$nama] = [
                'semester' => $meta[$nama]['semester'] ?? $semester_label,
                'periode'  => $meta[$nama]['periode']  ?? $periode_label,
                'tanggal'  => $kosong,
            ];
        }
    }
 
    $resp = [
        'data' => $missing,
        'meta' => [
            'kelas'    => '-',  
            'semester' => $semester_label,
            'periode'  => $periode_label,
        ],
    ];

    if (empty($missing)) {
        echo json_encode(['data' => new stdClass(), 'meta' => $resp['meta']]);
        return;
    }

    echo json_encode($resp);
}

public function laporan_resume_tanggal_guru_belum_diisi()
{
    // --- Ambil input ---
    $dari_tanggal        = $this->input->post('dari_tanggal') ? date('d-m-Y', strtotime($this->input->post('dari_tanggal'))) : null;
    $sampai_tanggal      = $this->input->post('sampai_tanggal') ? date('d-m-Y', strtotime($this->input->post('sampai_tanggal'))) : null;
    $filter              = $this->input->post('filter');           // 'tanggal' | 'bulan' | 'tahun'
    $periode             = $this->input->post('periode');          // a.id_periode (opsional)
    $semester            = $this->input->post('semester');         // label/kode semester (opsional)
    $bulan               = $this->input->post('bulan');
    $tahun               = $this->input->post('tahun');
    $single_filter_tahun = $this->input->post('single_filter_tahun');

    // --- Master GURU (jabatan = 'Guru') ---
    $sqlGuru = "
        SELECT a.nama_pegawai AS nama_guru
        FROM pegawai a
        LEFT JOIN pegawai_jabatan b ON a.id = b.id_pegawai
        WHERE b.jabatan = 'Guru'
    ";
    $guruRows   = $this->db->query($sqlGuru)->result_array();
    $daftarGuru = array_map(fn($x) => trim($x['nama_guru']), $guruRows);

    // --- Bangun allDates sesuai filter ---
    $allDates = [];
    if ($filter === 'tanggal' && $dari_tanggal && $sampai_tanggal) {
        $start = DateTime::createFromFormat('d-m-Y', $dari_tanggal);
        $end   = DateTime::createFromFormat('d-m-Y', $sampai_tanggal);
        if ($start && $end && $start <= $end) {
            $endInc = (clone $end)->modify('+1 day');
            $period = new DatePeriod($start, new DateInterval('P1D'), $endInc);
            foreach ($period as $dt) $allDates[] = $dt->format('d-m-Y');
        }
        $periode_label = $dari_tanggal . ' s.d. ' . $sampai_tanggal;
    } elseif ($filter === 'bulan' && $bulan && $tahun) {
        $hari = cal_days_in_month(CAL_GREGORIAN, (int)$bulan, (int)$tahun);
        for ($d = 1; $d <= $hari; $d++) $allDates[] = sprintf('%02d-%02d-%04d', $d, $bulan, $tahun);
        $periode_label = sprintf('%02d-%04d', $bulan, $tahun);
    } else {
        $th = (int)($single_filter_tahun ?: $tahun);
        for ($m = 1; $m <= 12; $m++) {
            $hari = cal_days_in_month(CAL_GREGORIAN, $m, $th);
            for ($d = 1; $d <= $hari; $d++) $allDates[] = sprintf('%02d-%02d-%04d', $d, $m, $th);
        }
        $periode_label = (string)$th;
    }

    if (empty($allDates)) {
        echo json_encode(['data' => new stdClass(), 'meta' => ['kelas' => '-', 'semester' => ($semester ?: '-'), 'periode' => ($periode_label ?: '-')]]); 
        return;
    }

    // --- Query jurnal_guru + kelas, sesuai filter (pakai COALESCE tanggal_input/tanggal) ---
    $params = [];
    $where  = [];

    if ($filter === 'tanggal' && $dari_tanggal && $sampai_tanggal) {
        $where[]  = "STR_TO_DATE(COALESCE(a.tanggal_input, a.tanggal), '%d-%m-%Y') BETWEEN STR_TO_DATE(?, '%d-%m-%Y') AND STR_TO_DATE(?, '%d-%m-%Y')";
        $params[] = $dari_tanggal;
        $params[] = $sampai_tanggal;
    } elseif ($filter === 'bulan' && $bulan && $tahun) {
        $where[]  = "MONTH(STR_TO_DATE(COALESCE(a.tanggal_input, a.tanggal), '%d-%m-%Y')) = ?";
        $where[]  = "YEAR(STR_TO_DATE(COALESCE(a.tanggal_input, a.tanggal), '%d-%m-%Y')) = ?";
        $params[] = $bulan;
        $params[] = $tahun;
    } else {
        $th = (int)($single_filter_tahun ?: $tahun);
        $where[]  = "YEAR(STR_TO_DATE(COALESCE(a.tanggal_input, a.tanggal), '%d-%m-%Y')) = ?";
        $params[] = $th;
    }

    if (!empty($periode))  { $where[] = "a.id_periode = ?"; $params[] = $periode; }
    if (!empty($semester)) { $where[] = "a.semester   = ?"; $params[] = $semester; }

    $sqlRows = "
        SELECT a.nama_guru,
               a.tanggal_input,
               a.tanggal,
               a.semester,
               a.id_periode,
               a.mapel,
               a.id_kelas,
               k.nama_kelas,
               k.kode_kelas
        FROM jurnal_guru a
        LEFT JOIN kelas k ON a.id_kelas = k.id
        " . (empty($where) ? "" : "WHERE " . implode(" AND ", $where)) . "
        ORDER BY STR_TO_DATE(COALESCE(a.tanggal_input, a.tanggal), '%d-%m-%Y') ASC
    ";
    $rows = $this->db->query($sqlRows, $params)->result_array();

    // --- Tandai tanggal yang sudah diisi per guru + simpan meta (mapel/kelas) ---
    $filled = []; // [nama_guru => ['dd-mm-YYYY' => true]]
    $meta   = []; // [nama_guru => ['semester','periode','mapel','nama_kelas','kode_kelas']]
    foreach ($rows as $r) {
        $raw = $r['tanggal_input'] ?: $r['tanggal'];
        if (!$raw) continue;

        $dt = DateTime::createFromFormat('d-m-Y', trim($raw));
        if (!$dt) continue;

        $tgl  = $dt->format('d-m-Y');
        $nama = trim($r['nama_guru']);
        if ($nama === '') continue;

        $filled[$nama][$tgl] = true;

        // Ambil meta. Jika guru mengajar banyak mapel/kelas, di sini akan “mengambil salah satu”
        // (terakhir yang ditemui). Jika perlu per-mapel/per-kelas, perlu dipecah per kombinasi.
        $meta[$nama]['semester']   = $r['semester']   ?? ($semester ?: '-');
        $meta[$nama]['periode']    = $periode_label;
        $meta[$nama]['mapel']      = $r['mapel']      ?? '-';
        $meta[$nama]['nama_kelas'] = $r['nama_kelas'] ?? '-';
        $meta[$nama]['kode_kelas'] = $r['kode_kelas'] ?? '-';
    }

    // --- Hitung tanggal KOSONG per guru master ---
    $missing = [];  
    $semester_label = $semester ?: '-';

    foreach ($daftarGuru as $nama) {
        $nama   = trim($nama);
        $sudah  = isset($filled[$nama]) ? array_keys($filled[$nama]) : [];
        $kosong = array_values(array_diff($allDates, $sudah));
        sort($kosong);

        if (!empty($kosong)) {
            $missing[$nama] = [
                'semester'   => $meta[$nama]['semester']   ?? $semester_label,
                'periode'    => $meta[$nama]['periode']    ?? $periode_label,
                'mapel'      => $meta[$nama]['mapel']      ?? '-',
                'nama_kelas' => $meta[$nama]['nama_kelas'] ?? '-',
                'kode_kelas' => $meta[$nama]['kode_kelas'] ?? '-',
                'tanggal'    => $kosong,
            ];
        }
    }

    // --- Meta header (opsional) ---
    $resp = [
        'data' => $missing,
        'meta' => [
            'kelas'    => '-',             // laporan agregat; bukan per kelas spesifik
            'semester' => $semester_label,
            'periode'  => $periode_label,
        ],
    ];

    echo json_encode( empty($missing) ? ['data' => new stdClass(), 'meta' => $resp['meta']] : $resp );
}


	public function laporan_izin_pegawai()
	{
		$dari_tanggal = date('d-m-Y', strtotime($this->input->post('dari_tanggal')));
		$sampai_tanggal = date('d-m-Y', strtotime($this->input->post('sampai_tanggal')));


		$filter = $this->input->post('filter');


		if ($filter == 'tanggal') {

			$pegawai = $this->db->query("SELECT a.* FROM izin_pegawai a  
					WHERE STR_TO_DATE(a.tgl_tidak_hadir, '%d-%m-%Y') BETWEEN STR_TO_DATE('$dari_tanggal', '%d-%m-%Y') 
					AND STR_TO_DATE('$sampai_tanggal', '%d-%m-%Y')   Order by a.tgl_tidak_hadir asc")->result_array();
			$grouped_by_tanggal = [];

			foreach ($pegawai as $data) {
				$tanggal = $data['tgl_tidak_hadir'];
				if (!isset($grouped_by_tanggal[$tanggal])) {
					$grouped_by_tanggal[$tanggal] = [];
				}
				$grouped_by_tanggal[$tanggal][] = $data;
			}

			$data = $grouped_by_tanggal;
		} else if ($filter == 'bulan') {
			$bulan = $this->input->post('bulan');
			$tahun = $this->input->post('tahun');

			$pegawai = $this->db->query("SELECT a.* FROM izin_pegawai a  WHERE MONTH(STR_TO_DATE(a.tgl_tidak_hadir, '%d-%m-%Y')) = $bulan AND YEAR(STR_TO_DATE(a.tgl_tidak_hadir, '%d-%m-%Y')) = $tahun
	  Order by a.tgl_tidak_hadir asc")->result_array();
			foreach ($pegawai as $data) {
				$tanggal = $data['tgl_tidak_hadir'];
				if (!isset($grouped_by_tanggal[$tanggal])) {
					$grouped_by_tanggal[$tanggal] = [];
				}
				$grouped_by_tanggal[$tanggal][] = $data;
			}
			$data = $grouped_by_tanggal;
		} else {
			$tahun = $this->input->post('single_filter_tahun');
			$pegawai = $this->db->query("SELECT a.* FROM izin_pegawai a  WHERE YEAR(STR_TO_DATE(a.tgl_tidak_hadir, '%d-%m-%Y')) = $tahun
			Order by a.tgl_tidak_hadir asc")->result_array();
			foreach ($pegawai as $data) {
				$tanggal = $data['tgl_tidak_hadir'];
				if (!isset($grouped_by_tanggal[$tanggal])) {
					$grouped_by_tanggal[$tanggal] = [];
				}
				$grouped_by_tanggal[$tanggal][] = $data;
			}

			$data = $grouped_by_tanggal;
		}

		echo json_encode($data);
	}
public function laporan_presensi_pegawai()
	{
		$dari_tanggal = date('d-m-Y', strtotime($this->input->post('dari_tanggal')));
		$sampai_tanggal = date('d-m-Y', strtotime($this->input->post('sampai_tanggal')));


		$filter = $this->input->post('filter');
		if ($filter == 'tanggal') {
			$pegawai_list = $this->db->query("SELECT * FROM pegawai_jabatan")->result_array();
// 			$grouped_by_tanggal = [];
// $start = strtotime($dari_tanggal);
// $end = strtotime($sampai_tanggal);
// for ($current=$start; $current <= $end ; $current++) { 
// 	$tanggal = date('d-m-Y', $current);
// 	foreach ($pegawai_list as $pegawai) {
// 		$presensi = $this->db->query("SELECT * FROM presensi_pegawai WHERE id_pegawai = ? AND tanggal = ?", [$pegawai['id_pegawai'], $tanggal])->row_array();
// 		 $grouped_by_tanggal[$tanggal][] = [
//             'nama_pegawai' => $pegawai['nama_pegawai'],
//             'jabatan' => $pegawai['jabatan'],
//             'status' => $presensi ? '1' : '0',
//             'jam_masuk' => $presensi['waktu'] ?? null,
//             'jam_pulang' => $presensi['jam_pulang'] ?? null,
//             'status_absen' => $presensi['status'] ?? null,
//         ];
// 	}
// }
  $pegawai_map = [];
    foreach ($pegawai_list as $p) {
        $pegawai_map[$p['id_pegawai']] = $p;
    }

    $presensi_all = $this->db->query("
        SELECT * FROM presensi_pegawai
        WHERE STR_TO_DATE(tanggal,'%d-%m-%Y')
        BETWEEN STR_TO_DATE(?,'%d-%m-%Y')
        AND STR_TO_DATE(?,'%d-%m-%Y')
    ", [$dari_tanggal, $sampai_tanggal])->result_array();

    $presensi_map = [];
    foreach ($presensi_all as $p) {
        $presensi_map[$p['tanggal']][$p['id_pegawai']] = $p;
    }

    
    $grouped_by_tanggal = [];
    $start = strtotime($dari_tanggal);
    $end = strtotime($sampai_tanggal);

    for ($current = $start; $current <= $end; $current = strtotime('+1 day', $current)) {
        $tanggal = date('d-m-Y', $current);

        foreach ($pegawai_map as $id => $pegawai) {
            $presensi = $presensi_map[$tanggal][$id] ?? null;

            $grouped_by_tanggal[$tanggal][] = [
                'nama_pegawai' => $pegawai['nama_pegawai'],
                'jabatan' => $pegawai['jabatan'],
                'status' => $presensi ? '1' : '0',
                'jam_masuk' => $presensi['waktu'] ?? null,
				'jam_terlambat' => $presensi['jam_terlambat'] ?? null,
                'jam_pulang' => $presensi['jam_pulang'] ?? null,
                'status_absen' => $presensi['status'] ?? null,
            ];
        }
    }
			$data = $grouped_by_tanggal;
		} else if ($filter == 'bulan') {
			$bulan = sprintf("%02d", $this->input->post('bulan'));
$tahun = $this->input->post('tahun');

$pegawai_list = $this->db->query("SELECT * FROM pegawai_jabatan")->result_array();
$pegawai_map = [];
foreach ($pegawai_list as $p) {
    $pegawai_map[$p['id_pegawai']] = $p;
}

$presensi_all = $this->db->query("
    SELECT * FROM presensi_pegawai
    WHERE MONTH(STR_TO_DATE(tanggal,'%d-%m-%Y')) = ?
      AND YEAR(STR_TO_DATE(tanggal,'%d-%m-%Y')) = ?
", [$bulan, $tahun])->result_array();

$presensi_map = [];
foreach ($presensi_all as $p) {
    $presensi_map[$p['tanggal']][$p['id_pegawai']] = $p;
}

$grouped_by_tanggal = [];
$total_days = cal_days_in_month(CAL_GREGORIAN, $bulan, $tahun);

for ($i = 1; $i <= $total_days; $i++) {
    $hari = sprintf("%02d", $i);
    $tanggal = "$hari-$bulan-$tahun";

    foreach ($pegawai_map as $id => $pegawai) {
        $presensi = $presensi_map[$tanggal][$id] ?? null;

        $grouped_by_tanggal[$tanggal][] = [
            'nama_pegawai' => $pegawai['nama_pegawai'],
            'jabatan' => $pegawai['jabatan'],
            'status' => $presensi ? '1' : '0',
            'jam_masuk' => $presensi['waktu'] ?? null,
			'jam_terlambat' => $presensi['jam_terlambat'] ?? null,
            'jam_pulang' => $presensi['jam_pulang'] ?? null,
            'status_absen' => $presensi['status'] ?? null,
        ];
    }
}

$data =   $grouped_by_tanggal;
		} else {
			$tahun = $this->input->post('single_filter_tahun');
$start = new DateTime("01-01-$tahun");
$end   = new DateTime("31-12-$tahun");
$end->modify('+1 day'); // agar 31-12 ikut
$pegawai_list = $this->db->query("SELECT * FROM pegawai_jabatan ")->result_array();
$period = new DatePeriod($start, new DateInterval("P1D"), $end);
$grouped_by_tanggal = [];
foreach ($period as $date) {
	$tanggal = $date->format('d-m-Y');
	foreach ($pegawai_list as $pegawai) {
		$presensi = $this->db->query("SELECT * FROM presensi_pegawai WHERE id_pegawai = ? AND tanggal = ?", [$pegawai['id_pegawai'], $tanggal])->row_array();
		$grouped_by_tanggal[$tanggal][] = [
			 'nama_pegawai' => $pegawai['nama_pegawai'],
            'jabatan' => $pegawai['jabatan'],
            'status' => $presensi ? '1' : '0',
            'jam_masuk' => $presensi['waktu'] ?? null,
			'jam_terlambat' => $presensi['jam_terlambat'] ?? null,
            'jam_pulang' => $presensi['jam_pulang'] ?? null,
            'status_absen' => $presensi['status'] ?? null,
		];
	}
	}

			$data = $grouped_by_tanggal;
		}

		echo json_encode($data);
	}

	public function laporan_presensi_per_pegawai()
	{
		$dari_tanggal = date('d-m-Y', strtotime($this->input->post('dari_tanggal')));
		$sampai_tanggal = date('d-m-Y', strtotime($this->input->post('sampai_tanggal')));
		$id_pegawai =  $this->input->post('id_pegawai');
		$pegawai = $this->db->query("SELECT nama_pegawai, jabatan FROM pegawai_jabatan WHERE id_pegawai = ?", [$id_pegawai])->row_array();
		$nama_pegawai = $pegawai['nama_pegawai'] ?? '-';
		$jabatan = $pegawai['jabatan'] ?? '-';

		$filter = $this->input->post('filter');
		if ($filter == 'tanggal') {
$grouped_by_tanggal = [];
$pegawai = $this->db->query("SELECT nama_pegawai, jabatan FROM pegawai_jabatan WHERE id_pegawai = ? ",[$id_pegawai])->row_array();
$nama_pegawai = $pegawai['nama_pegawai'] ?? '-';
$jabatan = $pegawai['jabatan'] ?? '-';
$start = strtotime($dari_tanggal);
			$end = strtotime($sampai_tanggal);
for ($ulang=$start; $ulang <= $end; $ulang = strtotime('+1 day', $ulang)) { 
	$tanggal = date('d-m-Y', $ulang);
	$presensi_pegawai = $this->db->query("SELECT a.*, b.* FROM pegawai_jabatan a LEFT JOIN presensi_pegawai b on b.id_pegawai = a.id_pegawai WHERE a.id_pegawai = ? AND b.tanggal = ?", [$id_pegawai, $tanggal])->row_array();
	if (empty($presensi_pegawai || empty($presensi_pegawai['tanggal']))) {
			$grouped_by_tanggal[$tanggal] = [
						'status' => '0',
						'tanggal' => $tanggal,
						'nama_pegawai' => $nama_pegawai,
						'jam_masuk' => null,
						'jam_terlambat' => null,
						'jam_pulang' => null,
						'status_absen' => 'Tidak Absen'
					];
	} else {
		$grouped_by_tanggal[$tanggal] = [
						'status' => '1',
						'tanggal' => $presensi_pegawai['tanggal'],
						'nama_pegawai' => $presensi_pegawai['nama_pegawai'],
						'jam_masuk' => $presensi_pegawai['waktu'] ?? null,
						'jam_terlambat' => $presensi_pegawai['jam_terlambat'] ?? null,
						'jam_pulang' => $presensi_pegawai['jam_pulang'] ?? null,
						'status_absen' => $presensi_pegawai['status'] ?? null,
					];
	}
	
}
			$response = [
    'meta' => [
        'nama_pegawai' => $nama_pegawai,
        'jabatan'      => $jabatan
    ],
    'data' => $grouped_by_tanggal
];

		} else if ($filter == 'bulan') {
			$pegawai = $this->db->query("SELECT nama_pegawai, jabatan FROM pegawai_jabatan WHERE id_pegawai = ?", [$id_pegawai])->row_array();
		$nama_pegawai = $pegawai['nama_pegawai'] ?? '-';
		$jabatan = $pegawai['jabatan'] ?? '-';
			$bulan = $this->input->post('bulan');
			$tahun = $this->input->post('tahun');
			$total_days = cal_days_in_month(CAL_GREGORIAN, $bulan, $tahun);
$grouped_by_tanggal = [];
for ($i=1; $i <= $total_days; $i++) { 
					$hari = sprintf("%02d", $i);
				$tanggal = $hari . '-' . $bulan . '-' . $tahun;

				$presensi_pegawai = $this->db->query("
        SELECT a.*, b.*
        FROM pegawai_jabatan a LEFT JOIN presensi_pegawai b on b.id_pegawai = a.id_pegawai
        WHERE a.id_pegawai = ?
          AND b.tanggal = ?
    ", [$id_pegawai, $tanggal])->row_array();

				if (empty($presensi_pegawai)) {
					$grouped_by_tanggal[$tanggal] = [
						'status' => '0',
						'tanggal' => $tanggal
					];
				} else {
					$grouped_by_tanggal[$tanggal] = [
						'status' => '1',
						'tanggal' => $presensi_pegawai['tanggal'],
						'nama_pegawai' => $presensi_pegawai['nama_pegawai'],
						'jam_masuk' => $presensi_pegawai['waktu'],
						'jam_terlambat' => $presensi_pegawai['jam_terlambat'],
						'jam_pulang' => $presensi_pegawai['jam_pulang'],
						'status_absen' => $presensi_pegawai['status'],
					];
				}
}
			$response = [
    'meta' => [
        'nama_pegawai' => $nama_pegawai,
        'jabatan'      => $jabatan
    ],
    'data' => $grouped_by_tanggal
];

		} else {
			$pegawai = $this->db->query("SELECT nama_pegawai, jabatan FROM pegawai_jabatan WHERE id_pegawai = ?", [$id_pegawai])->row_array();
		$nama_pegawai = $pegawai['nama_pegawai'] ?? '-';
		$jabatan = $pegawai['jabatan'] ?? '-';
			$tahun = $this->input->post('single_filter_tahun');
		$grouped_by_tanggal = [];
		for ($bulan=1; $bulan <= 12; $bulan++) { 
			$bulan_formatted = sprintf("%02d", $bulan);
			$total_days = cal_days_in_month(CAL_GREGORIAN, $bulan, $tahun);
			for ($hari=1; $hari <= $total_days ; $hari++) { 
				$hari_formatted = sprintf('%02d', $hari);
				$tanggal = $hari_formatted . '-' . $bulan_formatted . '-' . $tahun;
				$presensi_pegawai = $this->db->query("SELECT a.*, b.* FROM pegawai_jabatan a LEFT JOIN presensi_pegawai b on b.id_pegawai = a.id_pegawai WHERE a.id_pegawai = ? AND b.tanggal = ? ", [$id_pegawai, $tanggal])->row_array();
				if (empty($presensi_pegawai)) {
					$grouped_by_tanggal[$tanggal] = [
						  'status' => '0',
                    'tanggal' => $tanggal,
                    'nama_pegawai' => $nama_pegawai,
                    'jam_masuk' => null,
                    'jam_terlambat' => null,
                    'jam_pulang' => null,
                    'status_absen' => 'Tidak Absen'
					];
				} else {
					$grouped_by_tanggal[$tanggal] = [
                    'status' => '1',
                    'tanggal' => $presensi_pegawai['tanggal'],
                    'nama_pegawai' => $presensi_pegawai['nama_pegawai'],
                    'jam_masuk' => $presensi_pegawai['waktu'] ?? null,
                    'jam_terlambat' => $presensi_pegawai['jam_terlambat'] ?? null,
                    'jam_pulang' => $presensi_pegawai['jam_pulang'] ?? null,
                    'status_absen' => $presensi_pegawai['status'] ?? null,
                ];
				}
				 
			
		}}
				$response = [
    'meta' => [
        'nama_pegawai' => $nama_pegawai,
        'jabatan'      => $jabatan
    ],
    'data' => $grouped_by_tanggal
];
		}
		echo json_encode($response);
	}
	public function laporan_rekap_keterlambatan_pegawai()
	{
		$dari_tanggal = date('d-m-Y', strtotime($this->input->post('dari_tanggal')));
		$sampai_tanggal = date('d-m-Y', strtotime($this->input->post('sampai_tanggal')));


		$filter = $this->input->post('filter');
		if ($filter == 'tanggal') {
			$presensi_pegawai = $this->db->query("SELECT a.* FROM presensi_pegawai a  
					WHERE a.status = 'Terlambat' AND STR_TO_DATE(a.tanggal, '%d-%m-%Y') BETWEEN STR_TO_DATE('$dari_tanggal', '%d-%m-%Y') 
					AND STR_TO_DATE('$sampai_tanggal', '%d-%m-%Y')   Order by a.tanggal asc")->result_array();
			$grouped_by_tanggal = [];

			foreach ($presensi_pegawai as $data) {
				$tanggal = $data['tanggal'];
				if (!isset($grouped_by_tanggal[$tanggal])) {
					$grouped_by_tanggal[$tanggal] = [];
				}
				$grouped_by_tanggal[$tanggal][] = $data;
			}

			$data = $grouped_by_tanggal;
		} else if ($filter == 'bulan') {
			$bulan = $this->input->post('bulan');
			$tahun = $this->input->post('tahun');
			$presensi_pegawai = $this->db->query("SELECT a.* FROM presensi_pegawai a  WHERE a.status = 'Terlambat' AND MONTH(STR_TO_DATE(a.tanggal, '%d-%m-%Y')) = $bulan AND YEAR(STR_TO_DATE(a.tanggal, '%d-%m-%Y')) = $tahun
	  		Order by a.tanggal asc")->result_array();
			$grouped_by_tanggal = [];
			foreach ($presensi_pegawai as $data) {
				$tanggal = $data['tanggal'];
				if (!isset($grouped_by_tanggal[$tanggal])) {
					$grouped_by_tanggal[$tanggal] = [];
				}
				$grouped_by_tanggal[$tanggal][] = $data;
			}
			$data = $grouped_by_tanggal;
		} else {
			$tahun = $this->input->post('single_filter_tahun');
			$presensi_pegawai = $this->db->query("SELECT a.* FROM presensi_pegawai a  WHERE a.status = 'Terlambat' AND YEAR(STR_TO_DATE(a.tanggal, '%d-%m-%Y')) = $tahun
			Order by a.tanggal asc")->result_array();
			$grouped_by_tanggal = [];
			foreach ($presensi_pegawai as $data) {
				$tanggal = $data['tanggal'];
				if (!isset($grouped_by_tanggal[$tanggal])) {
					$grouped_by_tanggal[$tanggal] = [];
				}
				$grouped_by_tanggal[$tanggal][] = $data;
			}

			$data = $grouped_by_tanggal;
		}

		echo json_encode($data);
	}

}
?>
