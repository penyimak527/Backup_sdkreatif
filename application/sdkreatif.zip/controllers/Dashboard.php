<?php
class Dashboard extends CI_Controller
{

	function __construct()
	{
		parent::__construct();
		$this->load->model('M_dashboard', 'model');

	}

	public function index()
	{
		if ($this->session->userdata('admin')['username'] == null) {
			redirect('/');
		}


		$data['title'] = 'Dashboard';
		$data['total_mapel'] = $this->db->get('master_mata_pelajaran')->num_rows();

		$data['total_kelas'] = $this->db->get('kelas')->num_rows();
		$data['total_pegawai'] = $this->db->get('pegawai')->num_rows();
		$this->load->view('template/header', $data);
		$this->load->view('dashboard', $data);
		$this->load->view('template/footer');
	}

	public function mapel_result()
	{
		$data = $this->model->mapel_result();

		echo json_encode($data);
	}
	public function dashboard_result()
	{
		$data = $this->model->dashboard_result();

		echo json_encode($data);
	}
	public function jadwal_result()
	{
		$data = $this->model->jadwal_result();

		echo json_encode($data);
	}
	public function api_jadwal_result()
	{
		$data = $this->model->api_jadwal_result();

		echo json_encode($data);
	}


}
?>