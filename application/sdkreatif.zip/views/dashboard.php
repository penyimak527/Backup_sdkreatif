<div class="row row-cols-1 row-cols-md-3 g-4">
	<div class="col">
		<div class="card">
			<div class="d-flex card-header justify-content-between align-items-center">
				<div>
					<h4 class="header-title"> Mapel</h4>
				</div>

			</div>

			<div class="card-body pt-0">
				<div class="d-flex align-items-end gap-2 justify-content-between">
					<div class="text-end flex-shrink-0">
						<div id="chart-one" data-colors="#ff5b5b,#F6F7FB"></div>
					</div>
					<div class="text-end">
						<h3 class="fw-semibold"><?= $total_mapel ?></h3>
						<p class="text-muted mb-0">Total Mapel</p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col">
		<div class="card">
			<div class="d-flex card-header justify-content-between align-items-center">
				<div>
					<h4 class="header-title">Kelas</h4>
				</div>

			</div>

			<div class="card-body pt-0">
				<div class="d-flex align-items-end gap-2 justify-content-between">
					<div class="text-end flex-shrink-0">
						<div id="chart-two" data-colors="#f9c851,#F6F7FB"></div>
					</div>
					<div class="text-end">
						<h3 class="fw-semibold"><?= $total_kelas ?></h3>
						<p class="text-muted mb-0">Total Kelas</p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col">
		<div class="card">
			<div class="d-flex card-header justify-content-between align-items-center">
				<div>
					<h4 class="header-title">Pegawai</h4>
				</div>

			</div>

			<div class="card-body pt-0">
				<div class="d-flex align-items-end gap-2 justify-content-between">
					<div class="text-end flex-shrink-0">
						<div id="chart-three" data-colors="#ff5b5b,#F6F7FB"></div>
					</div>
					<div class="text-end">
						<h3 class="fw-semibold"><?= $total_pegawai ?></h3>
						<p class="text-muted mb-0">Total Pegawai</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php if ($this->session->userdata('admin')['level'] == 'Guru'): ?>
	<div class="card">
		<div class="card-header border-bottom border-dashed d-flex align-items-center justify-content-between">
			<h4 class="header-title">Jadwal Mengajar Hari Ini</h4>
		</div>
		<div class="card-body">

			<div id="card-container"></div>
		</div>
	</div>
<?php endif; ?>
<script>
	$(document).ready(function () {
		jadwal_hari_ini();
	})

	function jadwal_hari_ini() {
		$.ajax({
			url: '<?= base_url('dashboard/jadwal_result'); ?>',
			type: 'POST',
			dataType: 'JSON',
			success: function (data) {
				console.log(data)
				var tanggal = '<?= date('d-m-Y') ?>'
				var no = 1;
				var table = '';
				if (data.length == 0) {
					table += `
					<tr>
						<td colspan="7" style="text-align: center;">Tidak ada jadwal </td>
					</tr>
				`;
				} else {
					data.forEach(function (item) {
						// let detail = btoa(JSON.stringify(item));
						// table += `
						// <tr> 
						// 	<td>${item.mapel ?? ''}</td>
						// 	<td>${item.jam_pelajaran_awal ?? ''}- ${item.jam_pelajaran_akhir ?? ''}</td>
						// 	<td>${item.nama_kelas ?? ''}</td> 

						// 	<td>
						// 		<a href="<?= base_url(); ?>admin/kurikulum/jurnal/jurnal_guru/jurnal_mengajar/${item.id_jadwal}/${tanggal}" type="button" class="btn btn-sm btn-info" style="width:100%;"><i class="ri-error-warning-line"></i> Jurnal Kehadiran</a>
						// 	</td>
						// </tr>
						// `;
						table += `
							<div class="card-mapel">
								<p class="keterangan-hari">
									<span>Hari : ${item.hari}</span>
									<span>Semester (${item.semester})</span>
								</p>
								<div class="keterangan-mapel">
									<div class="keterangan-mapel-kiri">
										<h5 class="judul-mapel">${item.mapel}</h5>
										<h6 class="judul-mapel"> Kelas ${item.kelas} ${item.kode_kelas}</h6>
										<p class="keterangan-jam-mapel">Jam Pelajaran : ${item.jam_pelajaran_awal} - ${item.jam_pelajaran_akhir}</p>
									</div>
									<div class="keterangan-mapel-kanan">
										<a href="<?= base_url(); ?>admin/kurikulum/jurnal/jurnal_guru/jurnal_mengajar/${item.id_jadwal}/${tanggal}" type="button" class="btn btn-sm btn-info" style="width:100%;"><i class="ri-error-warning-line"></i> Jurnal Kehadiran</a>
									</div>
														</div>
													</div>`;
					});
				}
				$('#card-container').html(table);
			}
		});
	}
	document.addEventListener("DOMContentLoaded", function () {
		const defaultColors = ["#727cf5", "#0acf97", "#fa5c7c", "#ffbc00"];

		function renderRadialChart(selector, seriesValue) {
			const dataColors = document.querySelector(selector).dataset.colors;
			const colors = dataColors ? dataColors.split(",") : defaultColors;

			const options = {
				series: [seriesValue],
				chart: {
					type: "radialBar",
					height: 81,
					width: 81,
					sparkline: {
						enabled: false
					}
				},
				plotOptions: {
					radialBar: {
						offsetY: 0,
						hollow: {
							margin: 0,
							size: "50%"
						},
						dataLabels: {
							name: {
								show: false
							},
							value: {
								offsetY: 5,
								fontSize: "14px",
								fontWeight: "600",
								formatter: function (val) {
									return val;
								}
							}
						}
					}
				},
				grid: {
					padding: {
						top: -18,
						bottom: -20,
						left: -20,
						right: -20
					}
				},
				colors: colors
			};

			new ApexCharts(document.querySelector(selector), options).render();
		}

		// Panggil render untuk tiap chart
		renderRadialChart("#chart-one", <?= $total_mapel ?>);
		renderRadialChart("#chart-two", <?= $total_kelas ?>);
		renderRadialChart("#chart-three", <?= $total_pegawai ?>);
		renderRadialChart("#chart-four", 75);
	});

</script>