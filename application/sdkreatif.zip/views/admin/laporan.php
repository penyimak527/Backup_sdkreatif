<style>
	.scroll-wrapper {

		width: 100%;
		overflow: auto;
		max-height: 400px;
	}

	.excel-container {
		display: flex;
		flex-direction: column;
		gap: 12px;
		margin-top: 20px;
		font-family: 'Segoe UI', sans-serif;
		font-size: 14px;
	}


	.excel-header,
	.excel-row {
		display: grid;
		grid-template-columns: 50px 1fr 300px 80px 130px;
		gap: 15px;
		padding: 10px;
		border: 1px solid #ced4da;
		border-radius: 6px;
		align-items: center;
	}

	.excel-container.has-nama-col .excel-header,
	.excel-container.has-nama-col .excel-row {
		grid-template-columns: 50px 110px 200px 1fr 80px 130px;
		/* No, Tgl, Nama, Kegiatan, Semester, Periode */
	}

	.excel-header {
		border: 2px solid #009b4b;
		color: #009b4b;
		font-weight: 600;
	}

	.excel-row {
		border: 1px solid #6c757d;
		color: #343a40;
		margin-bottom: 10px;
	}

	.status-lulus {
		color: green;
		font-weight: 600;
	}

	.status-tidak {
		color: red;
		font-weight: 600;
	}

	@media screen and (max-width: 768px) {

		.excel-header,
		.excel-row {
			grid-template-columns: 1fr;
			padding: 10px;
		}

		.excel-header div::before,
		.excel-row div::before {
			content: attr(data-label) ": ";
			font-weight: 600;
			color: #6c757d;
		}

		.excel-header {
			display: none;
		}
	}
</style>


<div class="card">
	<div class="card-header border-bottom border-dashed d-flex align-items-center justify-content-between">
		<h4 class="header-title">Data <?= $title; ?></h4>

	</div>
	<div class="card-body">
		<div class="row">
			<div class="col-md-3">
				<div class="mb-3">
					<div class="input-group">
						<input type="text" class="form-control" id="cari-data-laporan" placeholder="Cari Laporan"
							aria-describedby="inputGroupPrepend" onkeyup="data_laporan()">
						<span class="input-group-text bg-primary text-white" id="inputGroupPrepend"><i
								class="ri-search-line"></i></span>
					</div>
				</div>
			</div>
		</div>
		<div style="height: 500px; overflow-y: auto; scroll-behavior: smooth;" id="data-laporan">
		</div>
	</div>
</div>

<div class="modal fade" id="printLaporan" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
	aria-hidden="true">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title" id="myLargeModalLabel"></h4>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body">
				<form id="form_laporan">
					<input type="hidden" id="path">
					<div class="row" id="filter-data" style="margin-bottom: 20px;">
						<div class="col-md-4">
							<div class="radio">
								<input type="radio" name="filter" id="filter_hari" value="tanggal" checked>
								<label for="filter_hari"> Hari </label>
							</div>
						</div>
						<div class="col-md-4">
							<div class="radio">
								<input type="radio" name="filter" id="filter_bulan" value="bulan">
								<label for="filter_bulan"> Bulan </label>
							</div>
						</div>
						<div class="col-md-4">
							<div class="radio">
								<input type="radio" name="filter" id="filter_tahun" value="tahun">
								<label for="filter_tahun"> Tahun </label>
							</div>
						</div>
					</div>
					<div id="form-hari" class="row mb-2">
						<div class="col-md-6">
							<div class="form-group">
								<label class="mb-1">Start</label>
								<input type="date" class="form-control" name="dari_tanggal">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label class="mb-1">End</label>
								<input type="date" class="form-control" name="sampai_tanggal">
							</div>
						</div>
					</div>

					<div id="form-bulan" class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label class="mb-1">Bulan</label>
								<select class="form-control" data-width="100%" name="filter_bulan">
									<?php
									$bulan = array("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");
									$jlh_bln = count($bulan);
									$no = 0;
									for ($c = 0; $c < $jlh_bln; $c += 1) {
										$no++;
										$no_pas = sprintf("%02s", $no);
										?>
										<option value="<?php echo $no_pas; ?>">
											<?php echo $bulan[$c]; ?>
										</option>
										<?php
									}
									?>
								</select>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label class="mb-1">Tahun</label>
								<select class="form-control" data-width="100%" name="filter_tahun">
									<?php
									$now = date('Y');
									for ($a = 2025; $a <= $now; $a++) {
										?>
										<option value="<?php echo $a; ?>">
											<?php echo $a; ?>
										</option>
										<?php
									}
									?>
								</select>
							</div>
						</div>
					</div>
					<div id="form-tahun" class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label class="mb-1">Tahun</label>
								<select class="form-control" data-width="100%" name="single_filter_tahun">
									<?php
									$now = date('Y');
									for ($a = 2025; $a <= $now; $a++) {
										?>
										<option value="<?php echo $a; ?>">
											<?php echo $a; ?>
										</option>
										<?php
									}
									?>
								</select>
							</div>
						</div>
					</div>
					<div id="form-jurnal-harian" class="row g-2" style="display: none;">
						<div class="col-md-12">
							<div class="form-group">
								<label class="mb-1">Guru</label>
								<select type="date" name="id_guru" class="form-control">
									<option value="">Pilih Guru</option>
									<?php
									foreach ($guru as $g): ?>
										?>
										<option value="<?php echo $g['id']; ?>">
											<?php echo $g['nama_guru']; ?>
										</option>
									<?php endforeach; ?>
								</select>
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label class="mb-1">Semester</label>
								<select name="semester" class="form-control">
									<option value="">Pilih Semester</option>
									<option value="Ganjil">Ganjil</option>
									<option value="Genap">Genap</option>
								</select>
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label class="mb-1">Tahun Ajaran</label>
								<select type="date" name="id_periode" class="form-control">
									<option value="">Pilih Tahun Ajaran</option>
									<?php
									foreach ($periode as $pe): ?>
										?>
										<option value="<?php echo $pe['id']; ?>">
											<?php echo $pe['periode']; ?>
										</option>
									<?php endforeach; ?>
								</select>
							</div>
						</div>
					</div>
					<div id="form-jurnal-guru" class="row g-2" style="display: none; margin-top: 10px;">
						<div class="col-md-12">
							<div class="form-group">
								<label class="mb-1">Kelas</label>
								<select type="date" name="id_kelas" class="form-control">
									<option data-kelas="Semua Kelas" value="Semua">Semua Kelas</option>
									<?php
									foreach ($kelas as $ke): ?>
										?>
										<option data-kelas="<?= $ke['nama_kelas']; ?>" value="<?php echo $ke['id']; ?>">
											<?= $ke['nama_kelas']; ?> 	<?= $ke['kode_kelas']; ?>
										</option>
									<?php endforeach; ?>
								</select>
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label class="mb-1">Semester</label>
								<select type="date" name="semester_jurnal" class="form-control">
									<option value="">Pilih Semester</option>
									<option value="Ganjil">Ganjil</option>
									<option value="Genap">Genap</option>
								</select>
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label class="mb-1">Tahun Ajaran</label>
								<select type="date" name="id_periode_jurnal" class="form-control">
									<option value="">Pilih Tahun Ajaran</option>
									<?php
									foreach ($periode as $pe): ?>
										?>
										<option data-tahun="<?= $pe['periode']; ?>" value="<?php echo $pe['id']; ?>">
											<?php echo $pe['periode']; ?>
										</option>
									<?php endforeach; ?>
								</select>
							</div>
						</div>
					</div>
					<div id="form-jurnal-kegiatan" class="row g-2" style="display: none; margin-top: 10px;">
						<div class="col-md-12">
							<div class="form-group">
								<label class="mb-1">Pegawai</label>
								<select type="date" name="id_pegawai" class="form-control"
									onchange="data_jurnal_pegawai()">
									<option value="">Semua Pegawai</option>
									<?php
									foreach ($pegawai as $ke): ?>
										?>
										<option data-label="<?= $ke['nama_pegawai']; ?>"
											data-jabatan="<?= $ke['jabatan']; ?>" value="<?php echo $ke['id_pegawai']; ?>">
											<?php echo $ke['nama_pegawai']; ?>
										</option>
									<?php endforeach; ?>
								</select>
							</div>
						</div>
					</div>
					<div id="form-pegawai-all" class="row g-2" style="display: none; margin-top: 10px;">
						<div class="col-md-12">
							<div class="form-group">
								<label class="mb-1">Pegawai</label>
								<select type="date" name="id_pegawai_all" class="form-control"
									onchange="data_presensi_per_pegawai()">
									<option value="">Pilih Pegawai</option>
									<?php foreach ($pegawai_all as $ke1): ?>
										<option data-label="<?= $ke1['nama_pegawai']; ?>" value="<?php echo $ke1['id']; ?>">
											<?php echo $ke1['nama_pegawai']; ?>
										</option>
									<?php endforeach; ?>
								</select>
							</div>
						</div>
					</div>

					<div id="form-resume-tanggal" class="row g-2" style="display: none; margin-top: 10px;">
						<div class="col-md-12">
							<div class="form-group">
								<label class="mb-1">Pilih Laporan</label>
								<select name="laporan" class="form-control" onchange="updateValExcel()">
									<option value="Guru">Jurnal Guru</option>
									<option value="Karyawan">Jurnal Karyawan</option>
								</select>
							</div>
						</div>
					</div>
				</form>
				<div class="modal-footer" style="margin-right:-22px;">
					<button type="button" class="btn btn-success waves-effect" name="print" value="excel"
						id="btn_print_laporan_excel"><i class="fa fa-file-excel me-1"></i>
						Excel</button>
					<button type="button" class="btn btn-info waves-effect" name="print" value="pdf"
						id="btn_print_laporan"><i class="fa fa-print me-1"></i>
						Print</button>
					<button type="button" class="btn btn-light" data-bs-dismiss="modal">Tutup</button>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="cek_excel" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
	aria-hidden="true">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title" id="myLargeModalLabel"></h4>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body">

				<table id="data_izin_pegawai" class="grid">
					<thead>
						<tr>
							<td>No</td>
							<td>TANGGAL</td>
							<td>NAMA PEGAWAI</td>
							<td>KETERANGAN</td>
							<td>ALASAN TIDAK HADIR</td>
						</tr>
					</thead>
					<tbody>

					</tbody>

				</table>
			</div>
		</div>
	</div>
</div>

<div class="jurnal_kegiatan" style="display: none;">
	<table>
		<tr>
			<td>Nama</td>
			<td>:</td>
			<td id="nama_pegawai"></td>
		</tr>
		<tr>
			<td>Jabatan</td>
			<td>:</td>
			<td id="jabatan"></td>
		</tr>
	</table>
	<div class="scroll-wrapper">
		<div class="excel-container">
			<div class="excel-header">
				<div data-label="No">No</div>
				<div data-label="Tanggal">Tanggal</div>
				<div data-label="Nama">Nama</div>
				<div data-label="Kegiatan">Kegiatan</div>
				<div data-label="Semester">Semester</div>
				<div data-label="Periode">Periode</div>
			</div>

			<div id="data_jurnal_pegawai">

			</div>
		</div>
	</div>
</div>

<div class="jurnal_guru_kelas" style="display: none;">
	<table style="width:100%; line-height: 1.5;">
		<tbody>
			<tr>
				<td style="width:7%; font-size:11px; text-transform:uppercase;">Kelas</td>
				<td style="width:1%; font-size:11px; text-transform:uppercase;">:</td>
				<td id="kelas"></td>
			</tr>
			<tr>
				<td style="width:7%; font-size:11px; text-transform:uppercase;">Semester</td>
				<td style="width:1%; font-size:11px; text-transform:uppercase;">:</td>
				<td id="semester"></td>
			</tr>
			<tr>
				<td style="width:7%; font-size:11px; text-transform:uppercase;">Tahun Ajaran</td>
				<td style="width:1%; font-size:11px; text-transform:uppercase;">:</td>
				<td id="periode"></td>
			</tr>
		</tbody>
	</table>
	<table id="data_jurnal_guru_kelas" class="grid">
		<thead>
			<tr>
				<td>No</td>
				<td>GURU</td>
				<td>MATAPELAJARAN</td>
				<td>KELAS</td>
				<td>JAM</td>
				<td>KEGIATAN</td>
				<td>TEMA</td>
				<td>Tanggal Mengajar</td>
			</tr>
		</thead>
		<tbody>

		</tbody>

	</table>
</div>
<div class="resume_tanggal_jurnal_kegiatan" style="display: none;">
	<table style="width:100%; line-height: 1.5;">
		<tbody>
			<tr>
				<td style="width:7%; font-size:11px; text-transform:uppercase;">Kelas</td>
				<td style="width:1%; font-size:11px; text-transform:uppercase;">:</td>
				<td id="kelas"></td>
			</tr>
			<tr>
				<td style="width:7%; font-size:11px; text-transform:uppercase;">Semester</td>
				<td style="width:1%; font-size:11px; text-transform:uppercase;">:</td>
				<td id="semester"></td>
			</tr>
			<tr>
				<td style="width:7%; font-size:11px; text-transform:uppercase;">Tahun Ajaran</td>
				<td style="width:1%; font-size:11px; text-transform:uppercase;">:</td>
				<td id="periode"></td>
			</tr>
		</tbody>
	</table>
	<table id="data_resume_tanggal_kegiatan" class="grid">
		<thead>
			<tr>
				<td>NO</td>
				<td>NAMA PEGAWAI</td>
				<td>TANGGAL BELUM DIISI</td>
				<td>SEMESTER</td>
				<td>PERIODE</td>
			</tr>
		</thead>
		<tbody>

		</tbody>

	</table>
</div>
<div class="resume_tanggal_jurnal_guru" style="display: none
;">
	<table style="width:100%; line-height: 1.5;">
		<tbody>
			<tr>
				<td style="width:7%; font-size:11px; text-transform:uppercase;">Kelas</td>
				<td style="width:1%; font-size:11px; text-transform:uppercase;">:</td>
				<td id="kelas"></td>
			</tr>
			<tr>
				<td style="width:7%; font-size:11px; text-transform:uppercase;">Semester</td>
				<td style="width:1%; font-size:11px; text-transform:uppercase;">:</td>
				<td id="semester"></td>
			</tr>
			<tr>
				<td style="width:7%; font-size:11px; text-transform:uppercase;">Tahun Ajaran</td>
				<td style="width:1%; font-size:11px; text-transform:uppercase;">:</td>
				<td id="periode"></td>
			</tr>
		</tbody>
	</table>
	<table id="data_resume_tanggal_guru" class="grid">
		<thead>
			<tr>
				<td>NO</td>
				<td>NAMA</td>
				<td>KELAS</td>
				<td>MATA PELAJARAN</td>
				<td>TANGGAL BELUM DIISI</td>
				<td>SEMESTER</td>
				<td>PERIODE</td>
			</tr>
		</thead>
		<tbody>

		</tbody>

	</table>
</div>
<div class="modal fade" id="cek_excel_pegawai" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
	aria-hidden="true">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title" id="myLargeModalLabel"></h4>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body">

				<table id="data_presensi_pegawai" class="grid">
					<thead>
						<tr>
							<td>No</td>
							<td>TANGGAL</td>
							<td>NAMA PEGAWAI</td>
							<td>JAM MASUK</td>
							<td>JAM TERLAMBAT</td>
							<td>JAM PULANG</td>
							<td>STATUS</td>
						</tr>
					</thead>
					<tbody>

					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<div class="modal fade" id="cek_excel_pegawai_terlambat" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
	aria-hidden="true">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title" id="myLargeModalLabel"></h4>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body">

				<table id="data_presensi_keterlambatan_pegawai" class="grid">
					<thead>
						<tr>
							<td>No</td>
							<td>TANGGAL</td>
							<td>NAMA PEGAWAI</td>
							<td>JABATAN</td>
							<td>STATUS</td>
							<td>MENIT TERLAMBAT</td>
						</tr>
					</thead>
					<tbody>

					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<div class="modal fade" id="cek_excel_per_pegawai" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
	aria-hidden="true">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title" id="myLargeModalLabel"></h4>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				<input type="hidden" id="nama_per_pegawai" disabled readonly>
				<input type="hidden" id="pegawai_per_jabatan" disabled readonly>
			</div>
			<div class="modal-body">

				<table id="data_presensi_per_pegawai" class="grid">
					<thead>
						<tr>
							<td>No</td>
							<td>TANGGAL</td>
							<td>JAM MASUK</td>
							<td>MENIT TERLAMBAT</td>
							<td>JAM PULANG</td>
							<td>STATUS</td>
						</tr>
					</thead>
					<tbody>

					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<script src="https://cdn.sheetjs.com/xlsx-latest/package/dist/xlsx.full.min.js"></script>

<script>
	$(document).ready(function () {
		data_laporan();
		$('#filter_hari').click(function () {
			$('#form-hari').show();
			$('#form-bulan').hide();
			$('#form-tahun').hide();
		});

		$('#filter_bulan').click(function () {
			$('#form-hari').hide();
			$('#form-bulan').show();
			$('#form-tahun').hide();
		});

		$('#filter_tahun').click(function () {
			$('#form-hari').hide();
			$('#form-bulan').hide();
			$('#form-tahun').show();
		});

		$('#btn_print_laporan').click(function () {
			var unindexed_array = $('#form_laporan').serializeArray();
			var indexed_array = {};

			$.map(unindexed_array, function (n, i) {
				indexed_array[n['name']] = n['value'];
			});
			indexed_array['print'] = 'pdf';
			let path = $('#path').val();

			$.ajax({
				url: '<?php echo base_url(); ?>' + path + '/print_laporan',
				data: JSON.stringify(indexed_array),
				contentType: "application/json",
				type: "POST",
				async: false,
				beforeSend: () => {
					$('#popup_load').show();
				},
				success: function (result) {

					let myWindow = window.open('', '_blank');
					myWindow.document.write(result);
				},
				complete: () => {
					$('#popup_load').fadeOut();
				}
			});
		});
		$('#btn_print_laporan_excel').click(function () {
			data_jurnal_pegawai();
			data_jurnal_guru_kelas();
			data_resume_tanggal_kegiatan();
			data_izin_pegawai();
			data_presensi_pegawai();
			data_presensi_keterlambatan_pegawai();
			data_presensi_per_pegawai();
			data_resume_tanggal_jurnal();
			// $('#printLaporan').modal('hide');
			// $('#cek_excel').modal('show');
			$('#btn_print_laporan_excel').attr('disabled', true);
			$('#btn_print_laporan_excel').html('<i class="fa fa-spinner fa-spin me-1"></i> Loading...');

		});

	})

	function data_laporan() {
		var search = $("#cari-data-laporan").val();

		$.ajax({
			url: '<?= base_url('admin/laporan/laporan_result'); ?>',
			type: 'POST',
			data: {
				search
			},
			dataType: 'JSON',
			success: function (data) {
				var table = '';
				if (data.length == 0) {
					table += `
					<tr>
						<td colspan="7" style="text-align: center;">Tidak ada data</td>
					</tr>
				`;
				} else {
					data.forEach(function (item) {
						if (item.name == "Laporan") {
							return;
						}
						table += `
						<div class="panel"
					style="box-shadow: 0 1px 4px 0 rgba(0,0,0,.1); border: 0.2px solid #E3E3E3; border-radius: 5px; margin-bottom: 25px;">
					<div class="card-header border-bottom order-dashed d-flex align-items-center  ">
						<h3>${item.name}  </h3>
					</div>
					<div class="card-body">
						<button type="button" class="btn btn-primary" name="button" onclick="klik_laporan('${item.name}','${item.path}')"><i class="fa fa-bookmark me-1"></i> Buka
							Laporan</button>
						</div>
					</div>
						`;
					});
				}
				$('#data-laporan').html(table);
			}
		});
	}

	function klik_laporan(nama, path) {
		$("#printLaporan").modal('show');
		$('#myLargeModalLabel').html(nama);
		$('#path').val(path);

		let link = '<?php echo base_url(); ?>' + path;
		$('#form_laporan').attr('action', link);

		if (nama == 'Laporan Jurnal Harian') {
			$('#filter-data').show();
			$('#form-hari').show();
			$('#form-bulan').hide();
			$('#form-tahun').hide();
			$('#form-jurnal-harian').show();
			$('#btn_print_laporan_excel').hide();
			$('#form-resume-tanggal').hide();


		} else if (nama == 'Laporan Jurnal Guru Per Kelas') {
			$('#filter-data').show();
			$('#form-hari').click();
			$('#form-bulan').hide();
			$('#form-tahun').hide();
			$('#form-jurnal-harian').hide();
			$('#form-jurnal-guru').show();
			$('#btn_print_laporan_excel').show();
			$('#form-jurnal-kegiatan').hide();
			$('#btn_print_laporan_excel').val('jurnal_guru_kelas');
			$('#form-resume-tanggal').hide();



		} else if (nama == 'Laporan Jurnal Kegiatan') {
			$('#filter-data').show();
			$('#form-hari').click();
			$('#form-bulan').hide();
			$('#form-tahun').hide();
			$('#form-jurnal-harian').hide();
			$('#form-jurnal-guru').hide();
			$('#form-jurnal-kegiatan').show();
			$('#form-resume-tanggal').hide();

			$('#btn_print_laporan_excel').show();
			$('#btn_print_laporan_excel').val('jurnal_kegiatan');

		} else if (nama == 'Laporan Izin Pegawai') {
			$('#filter-data').show();
			$('#form-hari').click();
			$('#form-bulan').hide();
			$('#form-tahun').hide();
			$('#form-jurnal-harian').hide();
			$('#form-jurnal-guru').hide();
			$('#form-jurnal-kegiatan').hide();
			$('#btn_print_laporan_excel').show();
			$('#btn_print_laporan_excel').val('izin_pegawai');
			$('#form-resume-tanggal').hide();


		} else if (nama == 'Laporan Resume Tanggal Belum Diisi') {
			$('#filter-data').show();
			$('#form-hari').click();
			$('#form-bulan').hide();
			$('#form-tahun').hide();
			$('#form-jurnal-harian').hide();
			$('#form-resume-tanggal').show();
			$('#form-jurnal-guru').hide();
			$('#form-jurnal-kegiatan').hide();
			$('#btn_print_laporan_excel').show();
			$('#btn_print_laporan_excel').val('Guru');

		} else if (nama == 'Laporan Presensi Pegawai') {
			$('#filter-data').show();
			$('#form-hari').click();
			$('#form-bulan').hide();
			$('#form-tahun').hide();
			$('#form-jurnal-harian').hide();
			$('#form-jurnal-guru').hide();
			$('#form-jurnal-kegiatan').hide();
			$('#form-pegawai-all').hide();
			$('#btn_print_laporan_excel').show();
			$('#btn_print_laporan_excel').val('presensi_pegawai');
			$('#form-resume-tanggal').hide();

		} else if (nama == 'Laporan Rekap Keterlambatan Pegawai') {
			$('#filter-data').show();
			$('#form-hari').click();
			$('#form-bulan').hide();
			$('#form-tahun').hide();
			$('#form-jurnal-harian').hide();
			$('#form-jurnal-guru').hide();
			$('#form-jurnal-kegiatan').hide();
			$('#form-pegawai-all').hide();
			$('#btn_print_laporan_excel').show();
			$('#btn_print_laporan_excel').val('rekap_presensi_keterlambatan_pegawai');
			$('#form-resume-tanggal').hide();
		} else if (nama == 'Laporan Presensi Per Pegawai') {
			$('#filter-data').show();
			$('#form-hari').click();
			$('#form-bulan').hide();
			$('#form-tahun').hide();
			$('#form-jurnal-harian').hide();
			$('#form-jurnal-guru').hide();
			$('#form-jurnal-kegiatan').hide();
			$('#form-pegawai-all').show();
			$('#btn_print_laporan_excel').show();
			$('#btn_print_laporan_excel').val('presensi_per_pegawai');
			$('#form-resume-tanggal').hide();
		} else {
			$('#form-laporan-presensi-siswa').hide();
			$('#form-jurnal-guru-kelas').hide();
			$('#form-jurnal-guru-tanggal').hide();
		}

		$('#laporan_presensi_siswa_filter').change(function () {
			var val = this.value;
			if (val == 1) {
				$("#laporan_presensi_siswa_filter_bulan").hide();
			} else {
				$("#laporan_presensi_siswa_filter_bulan").show();
			}
		});
	}

	function data_jurnal_pegawai() {
		var id_pegawai = $('select[name="id_pegawai"]').val();
		const isSemua = !id_pegawai; // '' atau null/undefined = semua

		// ambil label/jabatan dari option (kalau ada)
		const select = document.querySelector('select[name="id_pegawai"]');
		const selectedOption = select && select.options[select.selectedIndex];
		const namaPegawai = selectedOption ? (selectedOption.getAttribute('data-label') || '') : '';
		const jabatan = selectedOption ? (selectedOption.getAttribute('data-jabatan') || '') : '';

		// toggle info table di atas daftar
		const infoTable = document.querySelector('.jurnal_kegiatan > table');
		if (infoTable) {
			if (isSemua) {
				infoTable.style.display = '';
				$('#nama_pegawai').text('SEMUA PEGAWAI');
				$('#jabatan').text('-');
			} else {
				// JANGAN tampilin nama saat pilih 1 pegawai
				infoTable.style.display = 'none';
				$('#nama_pegawai').text('');
				$('#jabatan').text('');
			}
		}

		// kumpulkan filter
		var filter = $('input[name="filter"]:checked').val();
		var dari_tanggal = $('input[name="dari_tanggal"]').val();
		var sampai_tanggal = $('input[name="sampai_tanggal"]').val();
		var bulan = $('select[name="filter_bulan"]').val();
		var tahun = $('select[name="filter_tahun"]').val();
		var single_filter_tahun = $('select[name="single_filter_tahun"]').val();

		var dataPost = {
			dari_tanggal,
			sampai_tanggal,
			id_pegawai,
			filter,
			bulan,
			tahun,
			single_filter_tahun
		};

		$.ajax({
			url: '<?= base_url('admin/laporan/laporan_jurnal_pegawai'); ?>',
			type: 'POST',
			data: dataPost,
			dataType: 'JSON',
			success: function (data) {
				let no = 1;
				let html = '';

				// cek kosong
				const isEmptyArray = Array.isArray(data) && data.length === 0;
				const isEmptyObject = (data && typeof data === 'object' && !Array.isArray(data) && Object.keys(data).length === 0);
				if (!data || isEmptyArray || isEmptyObject) {
					$('#data_jurnal_pegawai').html('<div style="padding:10px; text-align:center;">Tidak ada data</div>');
					if (isSemua) {
						$('.excel-header').html(`
		<div data-label="No">No</div>
		<div data-label="Tanggal">Tanggal</div>
		<div data-label="Nama">Nama</div>
		<div data-label="Kegiatan">Kegiatan</div>
		<div data-label="Semester">Semester</div>
		<div data-label="Periode">Periode</div>
	  `);
						$('.excel-container').addClass('has-nama-col');
					} else {
						$('.excel-header').html(`
		<div data-label="No">No</div>
		<div data-label="Tanggal">Tanggal</div>
		<div data-label="Kegiatan">Kegiatan</div>
		<div data-label="Semester">Semester</div>
		<div data-label="Periode">Periode</div>
	  `);
						$('.excel-container').removeClass('has-nama-col');
					}
					return;
				}

				// Helper tanggal
				const parseDate = (str) => {
					if (!str) return null;
					// dukung "d-m-Y" dan "Y-m-d"
					const dmy = str.split('-');
					if (dmy.length === 3) {
						if (dmy[2].length === 4) { // d-m-Y
							const [d, m, y] = dmy.map(x => parseInt(x, 10));
							const dt = new Date(y, m - 1, d); // local
							return isNaN(dt) ? null : dt;
						} else { // Y-m-d
							const [y, m, d] = dmy.map(x => parseInt(x, 10));
							const dt = new Date(y, m - 1, d);
							return isNaN(dt) ? null : dt;
						}
					}
					// fallback Date()
					const dt = new Date(str);
					return isNaN(dt) ? null : dt;
				};
				const fmtDMY = (dt) => {
					const pad = (n) => String(n).padStart(2, '0');
					return `${pad(dt.getDate())}-${pad(dt.getMonth() + 1)}-${dt.getFullYear()}`;
				};
				const diffDays = (a, b) => {
					const ms = a.getTime() - b.getTime();
					return Math.floor(ms / 86400000);
				};

				if (isSemua) {
					// Header 6 kolom (dengan Nama)
					$('.excel-header').html(`
	  <div data-label="No">No</div>
	  <div data-label="Tanggal">Tanggal</div>
	  <div data-label="Nama">Nama</div>
	  <div data-label="Kegiatan">Kegiatan</div>
	  <div data-label="Semester">Semester</div>
	  <div data-label="Periode">Periode</div>
	`);
					$('.excel-container').addClass('has-nama-col');

					// data = { 'dd-mm-YYYY': [ {...}, {...} ], ... }
					const sortedDates = Object.keys(data).sort((a, b) => {
						const da = a.split('-').reverse().join(''); // YYYYMMDD
						const db = b.split('-').reverse().join('');
						return da.localeCompare(db);
					});

					sortedDates.forEach((tgl) => {
						const items = data[tgl] || [];
						items.forEach((item, idx) => {
							const tanggalCell = (idx === 0) ? (item.nama_pegawai || '-') : '';
							const groupStartAttr = (idx === 0) ? 'data-group-start="1"' : '';

							// === LOGIKA SAMA DENGAN TABEL PHP ===
							const dtKeg = parseDate(item.tanggal);
							let dtIn = parseDate(item.tanggal_input);
							const sameDay = (dtKeg && dtIn) ? (fmtDMY(dtKeg) === fmtDMY(dtIn)) : false;

							let selisihTxt = '';
							if (dtKeg && dtIn) {
								const d = diffDays(dtIn, dtKeg);
								if (d > 0) selisihTxt = ` (${d} hari)`;
							}

							if (sameDay) {
								// normal
								html += `
			<div class="excel-row" ${groupStartAttr} data-tanggal="${tgl}">
			  <div>${no++}</div>
			  <div class="cell-tanggal">${tanggalCell}</div>
			  <div>${item.tanggal || '-'} ${item.waktu || '-'}</div>
			  <div>${(item.kegiatan || '-')}<span class="muted">${selisihTxt}</span></div>
			  <div>${item.semester || '-'}</div>
			  <div>${item.periode || '-'}</div>
			</div>
		  `;
							} else {
								// merge 3 kolom terakhir
								const tInLbl = dtIn ? fmtDMY(dtIn) : '-';
								html += `
			<div class="excel-row" ${groupStartAttr} data-tanggal="${tgl}">
			  <div>${no++}</div>
			  <div class="cell-tanggal">${tanggalCell}</div>
			  <div>${item.tanggal || '-'} ${item.waktu || '-'}</div>
			  <div class="merge-3">
				<em>Belum diisi</em>
				${dtIn ? ` (tanggal input: ${tInLbl}${selisihTxt})` : ''}
			  </div>
			  <div class="merged-placeholder"></div>
			  <div class="merged-placeholder"></div>
			</div>
		  `;
							}
						});
					});

				} else {

					$('.excel-header').html(`
						<div data-label="No">No</div>
						<div data-label="Tanggal">Tanggal</div>
						<div data-label="Kegiatan">Kegiatan</div>
						<div data-label="Semester">Semester</div>
						<div data-label="Periode">Periode</div>
					`);
					$('.excel-container').removeClass('has-nama-col');


					data.forEach(function (item) {
						const dtKeg = parseDate(item.tanggal);
						const dtIn = parseDate(item.tanggal_input);
						const sameDay = (dtKeg && dtIn) ? (fmtDMY(dtKeg) === fmtDMY(dtIn)) : false;

						let selisihTxt = '';
						if (dtKeg && dtIn) {
							const d = diffDays(dtIn, dtKeg);
							if (d > 0) selisihTxt = ` (${d} hari)`;
						}

						if (sameDay) {
							html += `
		  <div class="excel-row">
			<div>${no++}</div>
			<div>${item.tanggal || '-'}</div>
			<div>${(item.kegiatan || '-')}<span class="muted">${selisihTxt}</span></div>
			<div>${item.semester || '-'}</div>
			<div>${item.periode || '-'}</div>
		  </div>
		`;
						} else {
							const tInLbl = dtIn ? fmtDMY(dtIn) : '-';
							html += `
		  <div class="excel-row">
			<div>${no++}</div>
			<div>${item.tanggal || '-'}</div>
			<div class="merge-3">
			  <em>Belum diisi </em>
			  ${dtIn ? ` (tanggal input: ${tInLbl}${selisihTxt})` : ''}
			</div>
			<div class="merged-placeholder"></div>
			<div class="merged-placeholder"></div>
		  </div>
		`;
						}
					});
				}

				$('#data_jurnal_pegawai').html(html);
			},

			error: function (xhr, status, error) {
				console.error('AJAX Error:', status, error);
				$('#data_jurnal_pegawai').html('<div style="padding:10px; text-align:center; color:red;">Gagal memuat data</div>');
			}
		});
	}

	function parseDMY(str) {

		if (!str || typeof str !== 'string') return null;
		const parts = str.trim().split('-');
		if (parts.length !== 3) return null;
		const [d, m, y] = parts.map(Number);
		if (!d || !m || !y) return null;
		const dt = new Date(y, m - 1, d);

		if (dt.getFullYear() !== y || dt.getMonth() !== m - 1 || dt.getDate() !== d) return null;
		return dt;
	}

	function formatDMY(date) {
		if (!(date instanceof Date)) return '';
		const d = String(date.getDate()).padStart(2, '0');
		const m = String(date.getMonth() + 1).padStart(2, '0');
		const y = date.getFullYear();
		return `${d}-${m}-${y}`;
	}

	function diffDays(a, b) {

		if (!(a instanceof Date) || !(b instanceof Date)) return 0;
		const aUTC = Date.UTC(a.getFullYear(), a.getMonth(), a.getDate());
		const bUTC = Date.UTC(b.getFullYear(), b.getMonth(), b.getDate());
		const ms = Math.abs(bUTC - aUTC);
		return Math.floor(ms / (1000 * 60 * 60 * 24));
	}

	function data_jurnal_guru_kelas() {

		const select = document.querySelector('select[name="id_kelas"]');
		const kelas = select?.options[select.selectedIndex]?.getAttribute('data-kelas') || '-';
		$('#kelas').text(kelas);

		const selectTahun = document.querySelector('select[name="id_periode_jurnal"]');
		const jurnal_periode = selectTahun?.options[selectTahun.selectedIndex]?.getAttribute('data-tahun') || '-';
		$('#periode').text(jurnal_periode);

		const filter = $('input[name="filter"]:checked').val();
		const id_kelas = $('select[name="id_kelas"]').val();
		const semester = $('select[name="semester_jurnal"]').val() || '-';
		$('#semester').text(semester);
		const periode = $('select[name="id_periode_jurnal"]').val();

		const dari_tanggal = $('input[name="dari_tanggal"]').val();
		const sampai_tanggal = $('input[name="sampai_tanggal"]').val();
		const bulan = $('select[name="filter_bulan"]').val();
		const tahun = $('select[name="filter_tahun"]').val();
		const single_filter_tahun = $('select[name="single_filter_tahun"]').val();

		const dataPost = { dari_tanggal, sampai_tanggal, bulan, tahun, single_filter_tahun, filter, id_kelas, semester, periode };

		$.ajax({
			url: '<?= base_url('admin/laporan/laporan_jurnal_guru_kelas'); ?>',
			type: 'POST',
			data: dataPost,
			dataType: 'JSON',
			success: function (data) {
				let no = 1, table = '';

				if (!data || Object.keys(data).length === 0) {
					table = '<tr><td colspan="8" class="text-center">Tidak ada data</td></tr>';
					$('#data_jurnal_guru_kelas tbody').html(table);
					return;
				}

				Object.keys(data).forEach(function (namaGuru) {
					const mapelList = data[namaGuru] || {};

					let totalBaris = 0;
					Object.keys(mapelList).forEach(mapel => {
						(mapelList[mapel] || []).forEach(item => {
							const tglMengajar = parseDMY((item.tanggal || '').trim());
							const tglInput = item.tanggal_input ? parseDMY(item.tanggal_input.trim()) : null;

							let isLate = false;
							if (tglMengajar && tglInput) {
								isLate = (diffDays(tglMengajar, tglInput) > 0) && (tglInput > tglMengajar);
							} else if (tglMengajar && !tglInput) {
								isLate = true;
							}
							totalBaris += 1 + (isLate ? 1 : 0);
						});
					});

					let guruRowspanAdded = false;

					Object.keys(mapelList).forEach(function (mapel) {
						const jadwalList = mapelList[mapel] || [];

						jadwalList.forEach(function (item) {
							const tglMengajarStr = (item.tanggal || '').trim();
							const tglInputStr = (item.tanggal_input || '').trim();
							const tglMengajar = parseDMY(tglMengajarStr);
							const tglInput = tglInputStr ? parseDMY(tglInputStr) : null;

							const expectedFillDate = tglMengajar ? new Date(tglMengajar.getTime()) : null;

							let daysLate = 0, isLate = false;
							if (tglMengajar && tglInput) {
								daysLate = diffDays(tglMengajar, tglInput);
								isLate = (daysLate > 0) && (tglInput > tglMengajar);
							} else if (tglMengajar && !tglInput) {
								const today = new Date();
								daysLate = diffDays(tglMengajar, today);
								isLate = true;
							}

							table += '<tr>';

							if (!guruRowspanAdded) {
								table += `<td rowspan="${totalBaris}">${no++}</td>`;
								table += `<td rowspan="${totalBaris}">${namaGuru}</td>`;
								guruRowspanAdded = true;
							}

							table += `<td>${mapel || '-'}</td>`;
							table += `<td>${item.nama_kelas || '-'}</td>`;
							table += `<td>${(item.jam_mulai_pelajaran || '-') + ' - ' + (item.jam_selesai_pelajaran || '-')}</td>`;
							table += `<td>${item.kegiatan || '-'}</td>`;
							table += `<td>${item.tema || '-'}</td>`;
							table += `<td>${tlg(tglMengajar, tglInput, daysLate)}</td>`;
							table += '</tr>';

							if (isLate) {
								const expectedStr = expectedFillDate ? formatDMY(expectedFillDate) : (tglMengajarStr || '-');
								const inputStr = tglInput ? formatDMY(tglInput) : '-';

								const note = `Seharusnya diisi: <b>${expectedStr}</b> <span class="badge-late">BELUM DIISI</span>`
									+ (tglInput ? ` — <span class="text-muted">Diinput: ${inputStr}</span>` : '');


								table += '<tr class="row-note">';

								table += '<td></td>';         // Mata Pelajaran (kosong)
								table += '<td></td>';         // Kelas (kosong)
								table += `<td colspan="4" style="text-align: center;">${note}</td>`; // Jam + Kegiatan + Tema + Tanggal Mengajar
								table += '</tr>';
							}
						});
					});
				});

				$('#data_jurnal_guru_kelas tbody').html(table);
			},
			error: function () {
				$('#data_jurnal_guru_kelas tbody').html(
					'<tr><td colspan="8" class="text-center">Gagal memuat data</td></tr>'
				);
			}
		});
	}

	function tlg(tglMengajar, tglInput, daysLate) {
		if (!tglMengajar) return '-';
		const base = formatDMY(tglMengajar);
		if (!tglInput) return base;
		if (daysLate > 0) return `${base} <span class="text-muted">(${daysLate} hari)</span>`;
		return base;
	}

	function data_izin_pegawai() {

		var filter = $('input[name="filter"]:checked').val();
		var dari_tanggal = $('input[name="dari_tanggal"]').val();
		var sampai_tanggal = $('input[name="sampai_tanggal"]').val();
		var bulan = $('select[name="filter_bulan"]').val();
		var tahun = $('select[name="filter_tahun"]').val();
		var single_filter_tahun = $('select[name="single_filter_tahun"]').val();
		var dataPost = {
			dari_tanggal,
			sampai_tanggal,
			bulan,
			tahun,
			single_filter_tahun,
			filter,
		};

		$.ajax({
			url: '<?= base_url('admin/laporan/laporan_izin_pegawai'); ?>',
			type: 'POST',
			data: dataPost,
			dataType: 'JSON',
			success: function (data) {

				var no = 1;
				var table = '';
				if (Object.keys(data).length === 0) {
					table = '<tr><td colspan="8" class="text-center">Tidak ada data</td></tr>';
				} else {

					Object.keys(data).forEach(function (tanggal) {
						let jadwalList = data[tanggal];
						let totalBaris = jadwalList.length;
						let guruRowspanAdded = false;

						jadwalList.forEach(function (item, index) {
							table += '<tr>';

							if (!guruRowspanAdded) {
								table += `<td rowspan="${totalBaris}">${no++}</td>`;
								table += `<td rowspan="${totalBaris}">${tanggal}</td>`;
								guruRowspanAdded = true;
							}

							table += `<td>${item.nama_pegawai}</td>`;
							table += `<td>${item.keterangan}</td>`;
							table += `<td>${item.alasan_tidak_hadir}</td>`;
							table += '</tr>';
						});
					});
				}

				$('#data_izin_pegawai tbody').html(table);

			}
		});
	}
	function data_resume_tanggal_kegiatan() {
		var filter = $('input[name="filter"]:checked').val();
		var dari_tanggal = $('input[name="dari_tanggal"]').val();
		var sampai_tanggal = $('input[name="sampai_tanggal"]').val();
		var bulan = $('select[name="filter_bulan"]').val();
		var tahun = $('select[name="filter_tahun"]').val();
		var single_filter_tahun = $('select[name="single_filter_tahun"]').val();

		var dataPost = {
			dari_tanggal,
			sampai_tanggal,
			bulan,
			tahun,
			single_filter_tahun,
			filter,
		};

		$.ajax({
			url: '<?= base_url('admin/laporan/laporan_resume_tanggal_kegiatan_belum_diisi'); ?>',
			type: 'POST',
			data: dataPost,
			dataType: 'JSON',
			success: function (resp) {
				// Jika server kirim wrapper { data: {...}, meta: {...} }
				var data = resp.data || resp;

				// (Opsional) Meta untuk header kecil di atas tabel
				if (resp.meta) {
					$('#kelas').text(resp.meta.kelas || '-');
					$('#semester').text(resp.meta.semester || '-');
					$('#periode').text(resp.meta.periode || '-');
				}

				var esc = function (s) {
					return String(s ?? '').replace(/[&<>"']/g, function (m) {
						return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[m]);
					});
				};

				var names = Object.keys(data).filter(function (k) { return k !== 'meta'; });

				var table = '';
				var no = 1;

				if (!names.length) {
					table = '<tr><td colspan="5" class="text-center">Tidak ada data</td></tr>';
				} else {
					// Urutkan nama pegawai (natural)
					names.sort(function (a, b) { return a.localeCompare(b, 'id', { numeric: true, sensitivity: 'base' }); });

					names.forEach(function (nama) {
						var item = data[nama] || {};
						var semester = item.semester ?? '-';
						var periode = item.periode ?? '-';
						var dates = Array.isArray(item.tanggal) ? item.tanggal.slice() : [];

						// Tampilkan HANYA pegawai yang masih punya tanggal kosong
						if (!dates.length) return;

						// Urutkan tanggal dd-mm-YYYY
						dates.sort(function (a, b) {
							var pa = a.split('-'), pb = b.split('-');
							// y-m-d untuk pembandingan
							var da = new Date(pa[2] + '-' + pa[1] + '-' + pa[0]);
							var db = new Date(pb[2] + '-' + pb[1] + '-' + pb[0]);
							return da - db;
						});

						var rowspan = dates.length;

						dates.forEach(function (tgl, idx) {
							table += '<tr>';
							if (idx === 0) {
								table += '<td rowspan="' + rowspan + '">' + (no++) + '</td>';
								table += '<td rowspan="' + rowspan + '">' + esc(nama) + '</td>';
							}

							table += '<td>' + esc(tgl) + '</td>';

							if (idx === 0) {
								table += '<td rowspan="' + rowspan + '">' + esc(semester) + '</td>';
								table += '<td rowspan="' + rowspan + '">' + esc(periode) + '</td>';
							}
							table += '</tr>';
						});
					});

					if (!table) {
						// Kalau semua pegawai lengkap (dates kosong semua)
						table = '<tr><td colspan="5" class="text-center">Semua pegawai sudah mengisi pada rentang ini.</td></tr>';
					}
				}

				$('#data_resume_tanggal_kegiatan tbody').html(table);
			}
		});
	}

	function data_resume_tanggal_jurnal() {
		const filter = $('input[name="filter"]:checked').val();
		const dari_tanggal = $('input[name="dari_tanggal"]').val();
		const sampai_tanggal = $('input[name="sampai_tanggal"]').val();
		const bulan = $('select[name="filter_bulan"]').val();
		const tahun = $('select[name="filter_tahun"]').val();
		const single_filter_tahun = $('select[name="single_filter_tahun"]').val();

		const dataPost = { dari_tanggal, sampai_tanggal, bulan, tahun, single_filter_tahun, filter };

		// Validasi sederhana
		if (filter === 'tanggal' && (!dari_tanggal || !sampai_tanggal)) {
			alert('Pastikan tanggal sudah dipilih.');
			return;
		}
		if (filter === 'bulan' && (!bulan || !tahun)) {
			alert('Pastikan bulan dan tahun dipilih.');
			return;
		}
		if (filter !== 'tanggal' && filter !== 'bulan' && !single_filter_tahun) {
			alert('Pastikan tahun dipilih.');
			return;
		}

		const $tbody = $('#data_resume_tanggal_guru tbody');
		$tbody.html('<tr><td colspan="7" class="text-center">Memuat...</td></tr>');

		$.ajax({
			url: '<?= base_url('admin/laporan/laporan_resume_tanggal_guru_belum_diisi'); ?>',
			type: 'POST',
			data: dataPost,
			dataType: 'JSON',
			success: function (resp) {
				const payload = (resp && typeof resp === 'object') ? (resp.data || resp) : {};
				const meta = resp && resp.meta ? resp.meta : null;

				if (meta) {
					$('#kelas').text(meta.kelas || '-');
					$('#semester').text(meta.semester || '-');
					$('#periode').text(meta.periode || '-');
				}

				const esc = (s) =>
					String(s ?? '').replace(/[&<>"']/g, (m) =>
						({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[m])
					);

				let names = Object.keys(payload).filter((k) => k !== 'meta');
				if (!names.length) {
					$tbody.html('<tr><td colspan="7" class="text-center">Tidak ada data</td></tr>');
					return;
				}

				names.sort((a, b) => a.localeCompare(b, 'id', { numeric: true, sensitivity: 'base' }));

				let html = '';
				let no = 1;

				names.forEach((nama) => {
					const item = payload[nama] || {};
					const dates = Array.isArray(item.tanggal) ? item.tanggal.slice() : [];
					const sem = item.semester ?? '-';
					const per = item.periode ?? '-';
					const mapel = item.mapel ?? '-';
					const kelas = (item.nama_kelas ?? '-') + (item.kode_kelas ? ` (${item.kode_kelas})` : '');

					if (!dates.length) return;

					dates.sort((a, b) => {
						const pa = a.split('-'), pb = b.split('-');
						const da = new Date(pa[2] + '-' + pa[1] + '-' + pa[0]);
						const db = new Date(pb[2] + '-' + pb[1] + '-' + pb[0]);
						return da - db;
					});

					const rowspan = dates.length;

					dates.forEach((tgl, idx) => {
						html += '<tr>';
						if (idx === 0) {
							html += `<td rowspan="${rowspan}">${no++}</td>`;
							html += `<td rowspan="${rowspan}">${esc(nama)}</td>`;
						}

						html += `<td>${esc(kelas)}</td>`;
						html += `<td>${esc(mapel)}</td>`;
						html += `<td>${esc(tgl)}</td>`;
						if (idx === 0) {
							html += `<td rowspan="${rowspan}">${esc(sem)}</td>`;
							html += `<td rowspan="${rowspan}">${esc(per)}</td>`;
						}
						html += '</tr>';
					});
				});

				if (!html) {
					html = '<tr><td colspan="7" class="text-center">Semua guru sudah mengisi pada rentang ini.</td></tr>';
				}

				$tbody.html(html);
			},
			error: function () {
				$tbody.html('<tr><td colspan="7" class="text-center text-danger">Gagal memuat data</td></tr>');
			},
		});
	}

	function data_presensi_pegawai() {
		var filter = $('input[name="filter"]:checked').val();
		var dari_tanggal = $('input[name="dari_tanggal"]').val();
		var sampai_tanggal = $('input[name="sampai_tanggal"]').val();
		var bulan = $('select[name="filter_bulan"]').val();
		var tahun = $('select[name="filter_tahun"]').val();
		var single_filter_tahun = $('select[name="single_filter_tahun"]').val();
		var dataPost = {
			dari_tanggal,
			sampai_tanggal,
			bulan,
			tahun,
			single_filter_tahun,
			filter,
		};

		$.ajax({
			url: '<?= base_url('admin/laporan/laporan_presensi_pegawai'); ?>',
			type: 'POST',
			data: dataPost,
			dataType: 'JSON',
			success: function (data) {
				var no = 1;
				var table = '';
				if (Object.keys(data).length === 0) {
					table = '<tr><td colspan="8" class="text-center">Tidak ada data</td></tr>';
				} else {

					Object.keys(data).forEach(function (tanggal) {
						let jadwalList = data[tanggal];
						let totalBaris = jadwalList.length;
						let guruRowspanAdded = false;

						jadwalList.forEach(function (item, index) {
							table += '<tr>';

							if (!guruRowspanAdded) {
								table += `<td rowspan="${totalBaris}">${no++}</td>`;
								table += `<td rowspan="${totalBaris}">${tanggal}</td>`;
								guruRowspanAdded = true;
							}
							if (item.status == '1') {
								table += `<td>${item.nama_pegawai}</td>`;
								// table += `<td>${item.jabatan}</td>`;
								table += `<td>${item.jam_masuk}</td>`;
								table += `<td>${item.jam_terlambat}</td>`;
								table += `<td>${item.jam_pulang ?? '-'}</td>`;
								table += `<td>${item.status_absen}</td>`;
							} else {
								table += `<td>${item.nama_pegawai}</td>`;
								table += `<td></td>`; // Jam Masuk
								table += `<td class="text-center">Tidak ada data</td>`;
								table += `<td></td>`; // Menit Terlambat
								table += `<td></td>`; // Jam Pulang
							}
							// table += `<td>${item.nama_pegawai}</td>`;
							// table += `<td>${item.jabatan}</td>`;
							// table += `<td>${item.jam_masuk}</td>`;
							// table += `<td>${item.jam_pulang?.trim() || '-'}</td>`;
							// table += `<td>${item.jam_terlambat}</td>`;
							// table += `<td>${item.status_absen}</td>`;
							table += '</tr>';
						});
					});
				}

				$('#data_presensi_pegawai tbody').html(table);

			}
		});
	}
	function data_presensi_keterlambatan_pegawai() {
		var filter = $('input[name="filter"]:checked').val();
		var dari_tanggal = $('input[name="dari_tanggal"]').val();
		var sampai_tanggal = $('input[name="sampai_tanggal"]').val();
		var bulan = $('select[name="filter_bulan"]').val();
		var tahun = $('select[name="filter_tahun"]').val();
		var single_filter_tahun = $('select[name="single_filter_tahun"]').val();
		var dataPost = {
			dari_tanggal,
			sampai_tanggal,
			bulan,
			tahun,
			single_filter_tahun,
			filter,
		};

		$.ajax({
			url: '<?= base_url('admin/laporan/laporan_rekap_keterlambatan_pegawai'); ?>',
			type: 'POST',
			data: dataPost,
			dataType: 'JSON',
			success: function (data) {
				var no = 1;
				var table = '';
				if (Object.keys(data).length === 0) {
					table = '<tr><td colspan="8" class="text-center">Tidak ada data</td></tr>';
				} else {

					Object.keys(data).forEach(function (tanggal) {
						let jadwalList = data[tanggal];
						let totalBaris = jadwalList.length;
						let guruRowspanAdded = false;

						jadwalList.forEach(function (item, index) {
							table += '<tr>';

							if (!guruRowspanAdded) {
								table += `<td rowspan="${totalBaris}">${no++}</td>`;
								table += `<td rowspan="${totalBaris}">${tanggal}</td>`;
								guruRowspanAdded = true;
							}

							table += `<td>${item.nama_pegawai}</td>`;
							table += `<td>${item.jabatan}</td>`;
							table += `<td>${item.status}</td>`;
							table += `<td>${item.jam_terlambat}</td>`;
							// table += `<td>${item.waktu}</td>`;
							table += '</tr>';
						});
					});
				}

				$('#data_presensi_keterlambatan_pegawai tbody').html(table);

			}
		});
	}
	function data_presensi_per_pegawai() {
		var filter = $('input[name="filter"]:checked').val();
		var dari_tanggal = $('input[name="dari_tanggal"]').val();
		var sampai_tanggal = $('input[name="sampai_tanggal"]').val();
		var bulan = $('select[name="filter_bulan"]').val();
		var tahun = $('select[name="filter_tahun"]').val();
		var id_pegawai = $('select[name="id_pegawai_all"]').val();
		var single_filter_tahun = $('select[name="single_filter_tahun"]').val();
		var dataPost = {
			dari_tanggal,
			sampai_tanggal,
			bulan,
			tahun,
			single_filter_tahun,
			filter,
			id_pegawai,
		};

		$.ajax({
			url: '<?= base_url('admin/laporan/laporan_presensi_per_pegawai'); ?>',
			type: 'POST',
			data: dataPost,
			dataType: 'JSON',
			success: function (data) {
				var no = 1;
				var table = '';
				const presensi = data.data;
				const nama_jabatan = data.meta;
				$('#nama_per_pegawai').val(nama_jabatan.nama_pegawai);
				$('#pegawai_per_jabatan').val(nama_jabatan.jabatan);

				if (!presensi || Object.keys(presensi).length === 0) {
					table = '<tr><td colspan="8" class="text-center">Tidak ada data</td></tr>';
				} else {

					Object.keys(presensi).forEach(function (tanggal) {
						const item = presensi[tanggal];

						table += '<tr>';
						table += `<td>${no++}</td>`; // nomor urut
						table += `<td>${tanggal}</td>`; // tanggal

						if (item.status === "1") {
							// Ada presensi
							table += `<td>${nama_jabatan.nama_pegawai}</td>`;
							table += `<td>${nama_jabatan.jabatan}</td>`; // jabatan dari nama_jabatan
							table += `<td>${item.jam_masuk}</td>`;
							table += `<td>${item.jam_terlambat}</td>`;
							table += `<td>${item.jam_pulang?.trim() || '-'}</td>`;
							table += `<td>${item.status_absen}</td>`;
						} else {
							// Tidak ada presensi
							table += `<td>${nama_jabatan.nama_pegawai}</td>`;
							table += `<td>${nama_jabatan.jabatan}</td>`;
							table += `<td></td>`; // Jam Masuk
							table += `<td  class="text-center">Tidak ada data</td>`;
							table += `<td></td>`; // Menit Terlambat
							table += `<td></td>`; // Jam Pulang
						}

						table += '</tr>';
					});
				}

				$('#data_presensi_per_pegawai tbody').html(table);

			}
		});
	}
</script>

<!-- laporan_excel -->
<script>
	function updateValExcel() {

		var val = $('select[name="laporan"]').val();


		$('#btn_print_laporan_excel').val(val);
	}
	document.getElementById("btn_print_laporan_excel").addEventListener("click", function () {

		var cek_btn = $('#btn_print_laporan_excel').val();
		if (cek_btn == 'jurnal_kegiatan') {
			const rows = document.querySelectorAll(".excel-container .excel-header, .excel-container .excel-row");
			const filter = document.querySelector('input[name="filter"]:checked').value;

			function doExport(filename, judul, subheaders) {
				let data = [];
				data.push([judul]);
				(subheaders || []).forEach(h => data.push([h]));
				data.push([]);

				const rows = document.querySelectorAll(".excel-container .excel-header, .excel-container .excel-row");
				rows.forEach(row => {
					const rowData = Array.from(row.querySelectorAll("div")).map(c => c.textContent.trim());
					data.push(rowData);
				});

				const ws = XLSX.utils.aoa_to_sheet(data);

				const headerCols = document.querySelectorAll(".excel-container .excel-header div").length;
				ws["!cols"] = (headerCols === 6)
					? [{ wch: 6 }, { wch: 14 }, { wch: 28 }, { wch: 40 }, { wch: 12 }, { wch: 12 }]
					: [{ wch: 6 }, { wch: 14 }, { wch: 40 }, { wch: 12 }, { wch: 12 }];


				if (headerCols === 6) {
					const merges = [];


					const headerRowIndex = 1 + (subheaders ? subheaders.length : 0) + 1;
					const firstDataRow = headerRowIndex + 1;
					const lastRow = data.length - 1;

					let spanStart = null;

					for (let r = firstDataRow; r <= lastRow; r++) {
						const tanggalVal = (data[r] && data[r][1]) ? data[r][1] : '';
						const prevTanggalVal = (data[r - 1] && data[r - 1][1]) ? data[r - 1][1] : '';

						if (tanggalVal) {
							if (spanStart !== null && (r - 1) > spanStart) {
								merges.push({ s: { r: spanStart, c: 1 }, e: { r: r - 1, c: 1 } });
							}
							spanStart = r;
						}


						if (r === lastRow && spanStart !== null && r > spanStart) {
							merges.push({ s: { r: spanStart, c: 1 }, e: { r: r, c: 1 } });
						}
					}

					if (merges.length) ws["!merges"] = (ws["!merges"] || []).concat(merges);
				}

				const wb = XLSX.utils.book_new();
				XLSX.utils.book_append_sheet(wb, ws, "Laporan Pegawai");
				XLSX.writeFile(wb, filename);

				$('#btn_print_laporan_excel').prop('disabled', false)
					.html('<i class="fa fa-file-excel me-1"></i> Excel');
			}





			if (filter === 'tanggal') {

				setTimeout(() => {
					let data = [];
					var tanggal_dari = document.querySelector('input[name="dari_tanggal"]') ? document.querySelector('input[name="dari_tanggal"]').value : '';
					var tanggal_sampai = document.querySelector('input[name="sampai_tanggal"]') ? document.querySelector('input[name="sampai_tanggal"]').value : '';
					var nama_pegawai = document.querySelector('#nama_pegawai') ? document.querySelector('#nama_pegawai').textContent : '';
					var jabatan = document.querySelector('#jabatan') ? document.querySelector('#jabatan').textContent : '';

					if (!tanggal_dari || !tanggal_sampai) {
						alert("Belum pilih tanggal.");
						return;
					}

					const { nama, jab } = getPegawaiInfo();
					const sub = [
						`Tanggal: ${formatTanggal(tanggal_dari)} s/d ${formatTanggal(tanggal_sampai)}`,
						`Nama Pegawai: ${nama}`,
						`Jabatan: ${jab}`
					];
					doExport(
						`laporan_jurnal_pegawai_tanggal_${formatTanggal(tanggal_dari)}_${formatTanggal(tanggal_sampai)}.xlsx`,
						"Laporan Jurnal Pegawai",
						sub
					);
				}, 1500);
			} else if (filter === 'bulan') {

				setTimeout(() => {
					let data = [];
					var bulan = document.querySelector('select[name="filter_bulan"]').value;
					var tahun = document.querySelector('select[name="filter_tahun"]').value;
					const { nama, jab } = getPegawaiInfo();
					const sub = [
						`Bulan: ${getNamaBulan(bulan)} ${tahun}`,
						`Nama Pegawai: ${nama}`,
						`Jabatan: ${jab}`
					];


					doExport(
						`laporan_jurnal_pegawai_bulan_${getNamaBulan(bulan)}_${tahun}.xlsx`,
						"Laporan Jurnal Pegawai",
						sub
					);
				}, 1500);
			} else {
				setTimeout(() => {
					var tahun = document.querySelector('select[name="single_filter_tahun"]').value;
					const { nama, jab } = getPegawaiInfo();
					const sub = [
						`Tahun: ${tahun}`,
						`Nama Pegawai: ${nama}`,
						`Jabatan: ${jab}`
					];


					doExport(
						`laporan_jurnal_pegawai_tahun_${tahun}.xlsx`,
						"Laporan Jurnal Pegawai",
						sub
					);
				}, 1500);
			}

		} else if (cek_btn == 'jurnal_guru_kelas') {
			const filter = document.querySelector('input[name="filter"]:checked')?.value;
			if (filter === 'tanggal') {
				setTimeout(() => {
					const tanggal_dari = document.querySelector('input[name="dari_tanggal"]')?.value || '';
					const tanggal_sampai = document.querySelector('input[name="sampai_tanggal"]')?.value || '';


					let data = [];
					var kelas = $('#kelas').text() || '';
					var semester = $('#semester').text() || '';
					var periode = $('#periode').text() || '';
					if (!tanggal_dari || !tanggal_sampai || !kelas || !semester || !periode) {
						alert("Pastikan tanggal, kelas, semester dan tahun ajaran sudah dipilih.");
						return;
					}

					// Header info
					data.push(["Laporan Jurnal Guru Kelas"]);
					data.push([`Tanggal: ${formatTanggal(tanggal_dari)} s/d ${formatTanggal(tanggal_sampai)}`]);
					data.push([`Kelas: ${kelas}`]);
					data.push([`Semester: ${semester}`]);
					data.push([`Tahun Ajaran: ${periode}`]);
					data.push([]);
					data.push(["No", "Guru", "Mata Pelajaran", "Kelas", "Jam", "Kegiatan", "Tema", "Tanggal Mengajar"]);

					const tableRows = document.querySelectorAll("#data_jurnal_guru_kelas tbody tr");

					let lastNo = '';
					let lastNamaGuru = '';
					let dataIndex = data.length;
					let mergeInstructions = [];

					let dataOffset = 7;
					let currentRowIndex = dataOffset;
					let spanStartIndex = null;
					let currentNo = '';
					let currentGuru = '';

					tableRows.forEach((row, idx) => {
						const cells = Array.from(row.cells).map(cell => cell.textContent.trim());
						let finalRow = [];

						if (cells.length === 6) {
							finalRow.push(lastNo);
							finalRow.push(lastNamaGuru);
							finalRow.push(...cells);
						} else {
							lastNo = cells[0];
							lastNamaGuru = cells[1];
							finalRow = cells;

							// Deteksi merge
							if (currentNo === lastNo && currentGuru === lastNamaGuru) {

							} else {
								// Tutup merge sebelumnya
								if (spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {
									// Merge kolom 0 (No) dan 1 (Guru)
									mergeInstructions.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
									mergeInstructions.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
								}

								// Reset merge tracker
								spanStartIndex = currentRowIndex;
								currentNo = lastNo;
								currentGuru = lastNamaGuru;
							}
						}

						data.push(finalRow);
						currentRowIndex++;
					});


					if (spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {
						mergeInstructions.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
						mergeInstructions.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
					}


					const worksheet = XLSX.utils.aoa_to_sheet(data);


					worksheet["!merges"] = mergeInstructions;

					// Set lebar kolom
					worksheet["!cols"] = [
						{ wch: 5 },   // No
						{ wch: 20 },  // Guru
						{ wch: 20 },  // Mapel
						{ wch: 10 },  // Kelas
						{ wch: 20 },  // Jam
						{ wch: 30 },  // Kegiatan
						{ wch: 30 },  // Tema
						{ wch: 25 }   // Tanggal Mengajar
					];

					// Wrap text
					const range = XLSX.utils.decode_range(worksheet['!ref']);
					for (let R = range.s.r; R <= range.e.r; ++R) {
						for (let C = range.s.c; C <= range.e.c; ++C) {
							const cell_address = XLSX.utils.encode_cell({ r: R, c: C });
							const cell = worksheet[cell_address];
							if (cell) {
								cell.s = cell.s || {};
								cell.s.alignment = { wrapText: true, vertical: "top" };
							}
						}
					}

					const workbook = XLSX.utils.book_new();
					XLSX.utils.book_append_sheet(workbook, worksheet, "Laporan Jurnal Guru Kelas");
					XLSX.writeFile(workbook, `laporan_jurnal_guru_kelas_${formatTanggal(tanggal_dari)}_${formatTanggal(tanggal_sampai)}.xlsx`);
					$('#btn_print_laporan_excel').attr('disabled', false);
					$('#btn_print_laporan_excel').html('<i class="fa fa-file-excel me-1"></i> Excel');
				}, 1500);

			} else if (filter === 'bulan') {

				setTimeout(() => {
					var bulan = document.querySelector('select[name="filter_bulan"]').value;
					var tahun = document.querySelector('select[name="filter_tahun"]').value;


					let data = [];
					var kelas = $('#kelas').text() || '';
					var semester = $('#semester').text() || '';
					var periode = $('#periode').text() || '';
					if (!kelas || !semester || !periode) {
						alert("Pastikan kelas, semester dan tahun ajaran sudah dipilih.");
						return;
					}

					// Header info
					data.push(["Laporan Jurnal Guru Kelas"]);
					data.push([`Bulan: ${getNamaBulan(bulan)} ${tahun}`]);
					data.push([`Kelas: ${kelas}`]);
					data.push([`Semester: ${semester}`]);
					data.push([`Tahun Ajaran: ${periode}`]);
					data.push([]);
					data.push(["No", "Guru", "Mata Pelajaran", "Kelas", "Jam", "Kegiatan", "Tema", "Tanggal Mengajar"]);

					const tableRows = document.querySelectorAll("#data_jurnal_guru_kelas tbody tr");

					let lastNo = '';
					let lastNamaGuru = '';
					let dataIndex = data.length;
					let mergeInstructions = [];

					let dataOffset = 7;
					let currentRowIndex = dataOffset;
					let spanStartIndex = null;
					let currentNo = '';
					let currentGuru = '';

					tableRows.forEach((row, idx) => {
						const cells = Array.from(row.cells).map(cell => cell.textContent.trim());
						let finalRow = [];

						if (cells.length === 6) {
							finalRow.push(lastNo);
							finalRow.push(lastNamaGuru);
							finalRow.push(...cells);
						} else {
							lastNo = cells[0];
							lastNamaGuru = cells[1];
							finalRow = cells;

							// Deteksi merge
							if (currentNo === lastNo && currentGuru === lastNamaGuru) {

							} else {

								if (spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {

									mergeInstructions.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
									mergeInstructions.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
								}


								spanStartIndex = currentRowIndex;
								currentNo = lastNo;
								currentGuru = lastNamaGuru;
							}
						}

						data.push(finalRow);
						currentRowIndex++;
					});


					if (spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {
						mergeInstructions.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
						mergeInstructions.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
					}


					const worksheet = XLSX.utils.aoa_to_sheet(data);


					worksheet["!merges"] = mergeInstructions;


					worksheet["!cols"] = [
						{ wch: 5 },
						{ wch: 20 },
						{ wch: 20 },
						{ wch: 10 },
						{ wch: 20 },
						{ wch: 30 },
						{ wch: 30 },
						{ wch: 25 }
					];


					const range = XLSX.utils.decode_range(worksheet['!ref']);
					for (let R = range.s.r; R <= range.e.r; ++R) {
						for (let C = range.s.c; C <= range.e.c; ++C) {
							const cell_address = XLSX.utils.encode_cell({ r: R, c: C });
							const cell = worksheet[cell_address];
							if (cell) {
								cell.s = cell.s || {};
								cell.s.alignment = { wrapText: true, vertical: "top" };
							}
						}
					}

					const workbook = XLSX.utils.book_new();
					XLSX.utils.book_append_sheet(workbook, worksheet, "Laporan Jurnal Guru Kelas");
					XLSX.writeFile(workbook, `laporan_jurnal_guru_kelas_${getNamaBulan(bulan)}_${tahun}.xlsx`);
					$('#btn_print_laporan_excel').attr('disabled', false);
					$('#btn_print_laporan_excel').html('<i class="fa fa-file-excel me-1"></i> Excel');
				}, 1500);
			} else {
				setTimeout(() => {
					var tahun = document.querySelector('select[name="single_filter_tahun"]').value;


					let data = [];
					var kelas = $('#kelas').text() || '';
					var semester = $('#semester').text() || '';
					var periode = $('#periode').text() || '';
					if (!kelas || !semester || !periode) {
						alert("Pastikan kelas, semester dan tahun ajaran sudah dipilih.");
						return;
					}

					// Header info
					data.push(["Laporan Jurnal Guru Kelas"]);
					data.push([`Tahun: ${tahun}`]);
					data.push([`Kelas: ${kelas}`]);
					data.push([`Semester: ${semester}`]);
					data.push([`Tahun Ajaran: ${periode}`]);
					data.push([]);
					data.push(["No", "Guru", "Mata Pelajaran", "Kelas", "Jam", "Kegiatan", "Tema", "Tanggal Mengajar"]);

					const tableRows = document.querySelectorAll("#data_jurnal_guru_kelas tbody tr");

					let lastNo = '';
					let lastNamaGuru = '';
					let dataIndex = data.length;
					let mergeInstructions = [];

					let dataOffset = 7;
					let currentRowIndex = dataOffset;
					let spanStartIndex = null;
					let currentNo = '';
					let currentGuru = '';

					tableRows.forEach((row, idx) => {
						const cells = Array.from(row.cells).map(cell => cell.textContent.trim());
						let finalRow = [];

						if (cells.length === 6) {
							finalRow.push(lastNo);
							finalRow.push(lastNamaGuru);
							finalRow.push(...cells);
						} else {
							lastNo = cells[0];
							lastNamaGuru = cells[1];
							finalRow = cells;

							// Deteksi merge
							if (currentNo === lastNo && currentGuru === lastNamaGuru) {

							} else {

								if (spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {

									mergeInstructions.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
									mergeInstructions.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
								}


								spanStartIndex = currentRowIndex;
								currentNo = lastNo;
								currentGuru = lastNamaGuru;
							}
						}

						data.push(finalRow);
						currentRowIndex++;
					});


					if (spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {
						mergeInstructions.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
						mergeInstructions.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
					}


					const worksheet = XLSX.utils.aoa_to_sheet(data);


					worksheet["!merges"] = mergeInstructions;


					worksheet["!cols"] = [
						{ wch: 5 },
						{ wch: 20 },
						{ wch: 20 },
						{ wch: 10 },
						{ wch: 20 },
						{ wch: 30 },
						{ wch: 30 },
						{ wch: 25 }
					];


					const range = XLSX.utils.decode_range(worksheet['!ref']);
					for (let R = range.s.r; R <= range.e.r; ++R) {
						for (let C = range.s.c; C <= range.e.c; ++C) {
							const cell_address = XLSX.utils.encode_cell({ r: R, c: C });
							const cell = worksheet[cell_address];
							if (cell) {
								cell.s = cell.s || {};
								cell.s.alignment = { wrapText: true, vertical: "top" };
							}
						}
					}

					const workbook = XLSX.utils.book_new();
					XLSX.utils.book_append_sheet(workbook, worksheet, "Laporan Jurnal Guru Kelas");
					XLSX.writeFile(workbook, `laporan_jurnal_guru_kelas_tahun_${tahun}.xlsx`);
					$('#btn_print_laporan_excel').attr('disabled', false);
					$('#btn_print_laporan_excel').html('<i class="fa fa-file-excel me-1"></i> Excel');
				}, 1500);
			}

		} else if (cek_btn === 'izin_pegawai') {
			const filter = document.querySelector('input[name="filter"]:checked')?.value;
			if (filter === 'tanggal') {
				setTimeout(() => {
					const tanggal_dari = document.querySelector('input[name="dari_tanggal"]')?.value || '';
					const tanggal_sampai = document.querySelector('input[name="sampai_tanggal"]')?.value || '';

					if (!tanggal_dari || !tanggal_sampai) {
						alert("Pastikan tanggal sudah dipilih.");
						return;
					}

					let data = [];

					// Header laporan
					data.push(["Laporan Izin Pegawai"]);
					data.push([`Tanggal: ${formatTanggal(tanggal_dari)} s/d ${formatTanggal(tanggal_sampai)}`]);
					data.push([]);
					data.push(["No", "Tanggal", "Nama Pegawai", "Keterangan", "Alasan Tidak Hadir"]);

					const tableRows = document.querySelectorAll("#data_izin_pegawai tbody tr");

					if (tableRows.length === 0) {
						alert("Tidak ada data untuk diekspor.");
						return;
					}

					let lastNo = '';
					let lastTanggal = '';
					let currentNo = '';
					let currentTanggal = '';
					let spanStartIndex = null;
					let currentRowIndex = data.length; // Start row index di Excel
					let mergeInstructions = [];

					tableRows.forEach((row, idx) => {
						const cells = Array.from(row.cells).map(cell => cell.textContent.trim());
						const isRowMerged = row.cells.length < 5;

						let finalRow = [];

						if (isRowMerged) {
							// Tambahkan nilai dari baris sebelumnya
							finalRow.push(lastNo);
							finalRow.push(lastTanggal);
							finalRow.push(...cells);
						} else {
							lastNo = cells[0];
							lastTanggal = cells[1];
							finalRow = cells;

							const isNewGroup = currentNo !== lastNo || currentTanggal !== lastTanggal;

							if (isNewGroup && spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {
								mergeInstructions.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
								mergeInstructions.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
							}

							if (isNewGroup) {
								spanStartIndex = currentRowIndex;
								currentNo = lastNo;
								currentTanggal = lastTanggal;
							}
						}

						data.push(finalRow);
						currentRowIndex++;

						if (idx === tableRows.length - 1 && spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {
							mergeInstructions.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
							mergeInstructions.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
						}
					});

					const worksheet = XLSX.utils.aoa_to_sheet(data);
					worksheet["!merges"] = mergeInstructions;

					worksheet["!cols"] = [
						{ wch: 5 },   // No
						{ wch: 20 },  // Tanggal
						{ wch: 25 },  // Nama Pegawai
						{ wch: 15 },  // Keterangan
						{ wch: 30 },
					];


					const range = XLSX.utils.decode_range(worksheet['!ref']);
					for (let R = range.s.r; R <= range.e.r; ++R) {
						for (let C = range.s.c; C <= range.e.c; ++C) {
							const cell_address = XLSX.utils.encode_cell({ r: R, c: C });
							const cell = worksheet[cell_address];
							if (cell) {
								cell.s = cell.s || {};
								cell.s.alignment = { wrapText: true, vertical: "top" };
							}
						}
					}


					const workbook = XLSX.utils.book_new();
					XLSX.utils.book_append_sheet(workbook, worksheet, "Laporan Izin Pegawai");
					XLSX.writeFile(workbook, `laporan_izin_pegawai_${formatTanggal(tanggal_dari)}_${formatTanggal(tanggal_sampai)}.xlsx`);


					$('#btn_print_laporan_excel').attr('disabled', false);
					$('#btn_print_laporan_excel').html('<i class="fa fa-file-excel me-1"></i> Excel');
				}, 1500);


			} else if (filter === 'bulan') {
				setTimeout(() => {
					const bulan = document.querySelector('select[name="filter_bulan"]')?.value || '';
					const tahun = document.querySelector('select[name="filter_tahun"]')?.value || '';



					let data = [];

					// Header laporan
					data.push(["Laporan Izin Pegawai"]);
					data.push([`Bulan: ${getNamaBulan(bulan)} ${tahun}`]);
					data.push([]);
					data.push(["No", "Tanggal", "Nama Pegawai", "Keterangan", "Alasan Tidak Hadir"]);

					const tableRows = document.querySelectorAll("#data_izin_pegawai tbody tr");

					if (tableRows.length === 0) {
						alert("Tidak ada data untuk diekspor.");
						return;
					}

					let lastNo = '';
					let lastTanggal = '';
					let currentNo = '';
					let currentTanggal = '';
					let spanStartIndex = null;
					let currentRowIndex = data.length; // Start row index di Excel
					let mergeInstructions = [];

					tableRows.forEach((row, idx) => {
						const cells = Array.from(row.cells).map(cell => cell.textContent.trim());
						const isRowMerged = row.cells.length < 5;

						let finalRow = [];

						if (isRowMerged) {
							// Tambahkan nilai dari baris sebelumnya
							finalRow.push(lastNo);
							finalRow.push(lastTanggal);
							finalRow.push(...cells);
						} else {
							lastNo = cells[0];
							lastTanggal = cells[1];
							finalRow = cells;

							const isNewGroup = currentNo !== lastNo || currentTanggal !== lastTanggal;

							if (isNewGroup && spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {
								mergeInstructions.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
								mergeInstructions.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
							}

							if (isNewGroup) {
								spanStartIndex = currentRowIndex;
								currentNo = lastNo;
								currentTanggal = lastTanggal;
							}
						}

						data.push(finalRow);
						currentRowIndex++;

						if (idx === tableRows.length - 1 && spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {
							mergeInstructions.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
							mergeInstructions.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
						}
					});

					const worksheet = XLSX.utils.aoa_to_sheet(data);
					worksheet["!merges"] = mergeInstructions;

					worksheet["!cols"] = [
						{ wch: 5 },   // No
						{ wch: 20 },  // Tanggal
						{ wch: 25 },  // Nama Pegawai
						{ wch: 15 },  // Keterangan
						{ wch: 30 },  // Alasan Tidak Hadir
					];


					const range = XLSX.utils.decode_range(worksheet['!ref']);
					for (let R = range.s.r; R <= range.e.r; ++R) {
						for (let C = range.s.c; C <= range.e.c; ++C) {
							const cell_address = XLSX.utils.encode_cell({ r: R, c: C });
							const cell = worksheet[cell_address];
							if (cell) {
								cell.s = cell.s || {};
								cell.s.alignment = { wrapText: true, vertical: "top" };
							}
						}
					}


					const workbook = XLSX.utils.book_new();
					XLSX.utils.book_append_sheet(workbook, worksheet, "Laporan Izin Pegawai");
					XLSX.writeFile(workbook, `laporan_izin_pegawai_bulan_${getNamaBulan(bulan)}_${tahun}.xlsx`);


					$('#btn_print_laporan_excel').attr('disabled', false);
					$('#btn_print_laporan_excel').html('<i class="fa fa-file-excel me-1"></i> Excel');
				}, 1500);
			} else {
				setTimeout(() => {
					const tahun = document.querySelector('select[name="single_filter_tahun"]')?.value || '';



					let data = [];

					// Header laporan
					data.push(["Laporan Izin Pegawai"]);
					data.push([`Tahun: ${tahun}`]);
					data.push([]);
					data.push(["No", "Tanggal", "Nama Pegawai", "Keterangan", "Alasan Tidak Hadir"]);

					const tableRows = document.querySelectorAll("#data_izin_pegawai tbody tr");

					if (tableRows.length === 0) {
						alert("Tidak ada data untuk diekspor.");
						return;
					}

					let lastNo = '';
					let lastTanggal = '';
					let currentNo = '';
					let currentTanggal = '';
					let spanStartIndex = null;
					let currentRowIndex = data.length; // Start row index di Excel
					let mergeInstructions = [];

					tableRows.forEach((row, idx) => {
						const cells = Array.from(row.cells).map(cell => cell.textContent.trim());
						const isRowMerged = row.cells.length < 5;

						let finalRow = [];

						if (isRowMerged) {
							// Tambahkan nilai dari baris sebelumnya
							finalRow.push(lastNo);
							finalRow.push(lastTanggal);
							finalRow.push(...cells);
						} else {
							lastNo = cells[0];
							lastTanggal = cells[1];
							finalRow = cells;

							const isNewGroup = currentNo !== lastNo || currentTanggal !== lastTanggal;

							if (isNewGroup && spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {
								mergeInstructions.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
								mergeInstructions.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
							}

							if (isNewGroup) {
								spanStartIndex = currentRowIndex;
								currentNo = lastNo;
								currentTanggal = lastTanggal;
							}
						}

						data.push(finalRow);
						currentRowIndex++;

						if (idx === tableRows.length - 1 && spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {
							mergeInstructions.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
							mergeInstructions.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
						}
					});

					const worksheet = XLSX.utils.aoa_to_sheet(data);
					worksheet["!merges"] = mergeInstructions;

					worksheet["!cols"] = [
						{ wch: 5 },   // No
						{ wch: 20 },  // Tanggal
						{ wch: 25 },  // Nama Pegawai
						{ wch: 15 },  // Keterangan
						{ wch: 30 },  // Alasan Tidak Hadir
					];


					const range = XLSX.utils.decode_range(worksheet['!ref']);
					for (let R = range.s.r; R <= range.e.r; ++R) {
						for (let C = range.s.c; C <= range.e.c; ++C) {
							const cell_address = XLSX.utils.encode_cell({ r: R, c: C });
							const cell = worksheet[cell_address];
							if (cell) {
								cell.s = cell.s || {};
								cell.s.alignment = { wrapText: true, vertical: "top" };
							}
						}
					}


					const workbook = XLSX.utils.book_new();
					XLSX.utils.book_append_sheet(workbook, worksheet, "Laporan Izin Pegawai");
					XLSX.writeFile(workbook, `laporan_izin_pegawai_tahun_${tahun}.xlsx`);


					$('#btn_print_laporan_excel').attr('disabled', false);
					$('#btn_print_laporan_excel').html('<i class="fa fa-file-excel me-1"></i> Excel');
				}, 1500);
			}
		} else if (cek_btn === 'presensi_pegawai') {
			const filter = document.querySelector('input[name="filter"]:checked')?.value;
			if (filter === 'tanggal') {
				setTimeout(() => {
					const tanggal_dari = document.querySelector('input[name="dari_tanggal"]')?.value || '';
					const tanggal_sampai = document.querySelector('input[name="sampai_tanggal"]')?.value || '';

					if (!tanggal_dari || !tanggal_sampai) {
						alert("Pastikan tanggal sudah dipilih.");
						return;
					}

					let data = [];

					// Header laporan
					data.push(["Laporan Presensi Pegawai"]);
					data.push([`Tanggal: ${formatTanggal(tanggal_dari)} s/d ${formatTanggal(tanggal_sampai)}`]);
					data.push([]);
					data.push(["No", "Tanggal", "Nama Pegawai", "Jam Masuk", "Menit Terlambat", "Jam Pulang", "Status"]);
					const tableRows = document.querySelectorAll("#data_presensi_pegawai tbody tr");

					if (tableRows.length === 0) {
						alert("Tidak ada data untuk diekspor.");
						return;
					}

					let lastNo = '';
					let lastTanggal = '';
					let currentNo = '';
					let currentTanggal = '';
					let spanStartIndex = null;
					let currentRowIndex = data.length; // Start row index di Excel
					let mergeInstructions = [];

					tableRows.forEach((row, idx) => {
						const cells = Array.from(row.cells).map(cell => cell.textContent.trim());
						const isRowMerged = row.cells.length < 7;

						let finalRow = [];

						if (isRowMerged) {
							// Tambahkan nilai dari baris sebelumnya
							finalRow.push(lastNo);
							finalRow.push(lastTanggal);
							finalRow.push(...cells);
						} else {
							lastNo = cells[0];
							lastTanggal = cells[1];
							finalRow = cells;

							const isNewGroup = currentNo !== lastNo || currentTanggal !== lastTanggal;

							if (isNewGroup && spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {
								mergeInstructions.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
								mergeInstructions.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
							}

							if (isNewGroup) {
								spanStartIndex = currentRowIndex;
								currentNo = lastNo;
								currentTanggal = lastTanggal;
							}
						}

						data.push(finalRow);
						currentRowIndex++;

						if (idx === tableRows.length - 1 && spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {
							mergeInstructions.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
							mergeInstructions.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
						}
					});

					const worksheet = XLSX.utils.aoa_to_sheet(data);
					worksheet["!merges"] = mergeInstructions;

					worksheet["!cols"] = [
						{ wch: 5 },   // No
						{ wch: 20 },  // Tanggal
						{ wch: 30 },  // Nama Pegawai
						{ wch: 30 },  // Status
						{ wch: 30 },  // Jam Terlambat
						{ wch: 30 },  // Jam Terlambat
						{ wch: 30 },  // Waktu
					];


					const range = XLSX.utils.decode_range(worksheet['!ref']);
					for (let R = range.s.r; R <= range.e.r; ++R) {
						for (let C = range.s.c; C <= range.e.c; ++C) {
							const cell_address = XLSX.utils.encode_cell({ r: R, c: C });
							const cell = worksheet[cell_address];
							if (cell) {
								cell.s = cell.s || {};
								cell.s.alignment = { wrapText: true, vertical: "top" };
							}
						}
					}


					const workbook = XLSX.utils.book_new();
					XLSX.utils.book_append_sheet(workbook, worksheet, "Laporan Presensi Pegawai");
					XLSX.writeFile(workbook, `laporan_presensi_pegawai_${formatTanggal(tanggal_dari)}_${formatTanggal(tanggal_sampai)}.xlsx`);


					$('#btn_print_laporan_excel').attr('disabled', false);
					$('#btn_print_laporan_excel').html('<i class="fa fa-file-excel me-1"></i> Excel');
				}, 1500);


			} else if (filter === 'bulan') {
				setTimeout(() => {
					const bulan = document.querySelector('select[name="filter_bulan"]')?.value || '';
					const tahun = document.querySelector('select[name="filter_tahun"]')?.value || '';



					let data = [];

					// Header laporan
					data.push(["Laporan Presensi Pegawai"]);
					data.push([`Bulan: ${getNamaBulan(bulan)} ${tahun}`]);
					data.push([]);
					data.push(["No", "Tanggal", "Nama Pegawai", "Jam Masuk", "Menit Terlambat", "Jam Pulang", "Status"]);

					const tableRows = document.querySelectorAll("#data_presensi_pegawai tbody tr");

					if (tableRows.length === 0) {
						alert("Tidak ada data untuk diekspor.");
						return;
					}

					let lastNo = '';
					let lastTanggal = '';
					let currentNo = '';
					let currentTanggal = '';
					let spanStartIndex = null;
					let currentRowIndex = data.length; // Start row index di Excel
					let mergeInstructions = [];

					tableRows.forEach((row, idx) => {
						const cells = Array.from(row.cells).map(cell => cell.textContent.trim());
						const isRowMerged = row.cells.length < 7;

						let finalRow = [];

						if (isRowMerged) {
							// Tambahkan nilai dari baris sebelumnya
							finalRow.push(lastNo);
							finalRow.push(lastTanggal);
							finalRow.push(...cells);
						} else {
							lastNo = cells[0];
							lastTanggal = cells[1];
							finalRow = cells;

							const isNewGroup = currentNo !== lastNo || currentTanggal !== lastTanggal;

							if (isNewGroup && spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {
								mergeInstructions.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
								mergeInstructions.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
							}

							if (isNewGroup) {
								spanStartIndex = currentRowIndex;
								currentNo = lastNo;
								currentTanggal = lastTanggal;
							}
						}

						data.push(finalRow);
						currentRowIndex++;

						if (idx === tableRows.length - 1 && spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {
							mergeInstructions.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
							mergeInstructions.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
						}
					});

					const worksheet = XLSX.utils.aoa_to_sheet(data);
					worksheet["!merges"] = mergeInstructions;

					worksheet["!cols"] = [
						{ wch: 5 },   // No
						{ wch: 20 },  // Tanggal
						{ wch: 30 },  // Nama Pegawai
						{ wch: 30 },  // Status
						{ wch: 30 },  // Jam Terlambat
						{ wch: 30 },  // Waktu
						{ wch: 30 },  // Waktu
					];


					const range = XLSX.utils.decode_range(worksheet['!ref']);
					for (let R = range.s.r; R <= range.e.r; ++R) {
						for (let C = range.s.c; C <= range.e.c; ++C) {
							const cell_address = XLSX.utils.encode_cell({ r: R, c: C });
							const cell = worksheet[cell_address];
							if (cell) {
								cell.s = cell.s || {};
								cell.s.alignment = { wrapText: true, vertical: "top" };
							}
						}
					}


					const workbook = XLSX.utils.book_new();
					XLSX.utils.book_append_sheet(workbook, worksheet, "Laporan Presensi Pegawai");
					XLSX.writeFile(workbook, `laporan_presensi_pegawai_bulan_${getNamaBulan(bulan)}_${tahun}.xlsx`);


					$('#btn_print_laporan_excel').attr('disabled', false);
					$('#btn_print_laporan_excel').html('<i class="fa fa-file-excel me-1"></i> Excel');
				}, 1500);
			} else {
				setTimeout(() => {
					const tahun = document.querySelector('select[name="single_filter_tahun"]')?.value || '';



					let data = [];

					// Header laporan
					data.push(["Laporan Presensi Pegawai"]);
					data.push([`Tahun: ${tahun}`]);
					data.push([]);
					data.push(["No", "Tanggal", "Nama Pegawai", "Jam Masuk", "Menit Terlambat", "Jam Pulang", "Status"]);

					const tableRows = document.querySelectorAll("#data_presensi_pegawai tbody tr");

					if (tableRows.length === 0) {
						alert("Tidak ada data untuk diekspor.");
						return;
					}

					let lastNo = '';
					let lastTanggal = '';
					let currentNo = '';
					let currentTanggal = '';
					let spanStartIndex = null;
					let currentRowIndex = data.length; // Start row index di Excel
					let mergeInstructions = [];

					tableRows.forEach((row, idx) => {
						const cells = Array.from(row.cells).map(cell => cell.textContent.trim());
						const isRowMerged = row.cells.length < 7;

						let finalRow = [];

						if (isRowMerged) {
							// Tambahkan nilai dari baris sebelumnya
							finalRow.push(lastNo);
							finalRow.push(lastTanggal);
							finalRow.push(...cells);
						} else {
							lastNo = cells[0];
							lastTanggal = cells[1];
							finalRow = cells;

							const isNewGroup = currentNo !== lastNo || currentTanggal !== lastTanggal;

							if (isNewGroup && spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {
								mergeInstructions.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
								mergeInstructions.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
							}

							if (isNewGroup) {
								spanStartIndex = currentRowIndex;
								currentNo = lastNo;
								currentTanggal = lastTanggal;
							}
						}

						data.push(finalRow);
						currentRowIndex++;

						if (idx === tableRows.length - 1 && spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {
							mergeInstructions.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
							mergeInstructions.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
						}
					});

					const worksheet = XLSX.utils.aoa_to_sheet(data);
					worksheet["!merges"] = mergeInstructions;

					worksheet["!cols"] = [
						{ wch: 5 },   // No
						{ wch: 20 },  // Tanggal
						{ wch: 30 },  // Nama Pegawai
						{ wch: 30 },  // Jam Masuk
						{ wch: 30 },  // Jam Terlambat
						{ wch: 30 },  // Status
						{ wch: 30 },  // Status
					];


					const range = XLSX.utils.decode_range(worksheet['!ref']);
					for (let R = range.s.r; R <= range.e.r; ++R) {
						for (let C = range.s.c; C <= range.e.c; ++C) {
							const cell_address = XLSX.utils.encode_cell({ r: R, c: C });
							const cell = worksheet[cell_address];
							if (cell) {
								cell.s = cell.s || {};
								cell.s.alignment = { wrapText: true, vertical: "top" };
							}
						}
					}


					const workbook = XLSX.utils.book_new();
					XLSX.utils.book_append_sheet(workbook, worksheet, "Laporan Presensi Pegawai");
					XLSX.writeFile(workbook, `laporan_presensi_pegawai_tahun_${tahun}.xlsx`);


					$('#btn_print_laporan_excel').attr('disabled', false);
					$('#btn_print_laporan_excel').html('<i class="fa fa-file-excel me-1"></i> Excel');
				}, 1500);
			}
		} else if (cek_btn === 'rekap_presensi_keterlambatan_pegawai') {
			const filter = document.querySelector('input[name="filter"]:checked')?.value;
			if (filter === 'tanggal') {
				setTimeout(() => {
					const tanggal_dari = document.querySelector('input[name="dari_tanggal"]')?.value || '';
					const tanggal_sampai = document.querySelector('input[name="sampai_tanggal"]')?.value || '';

					if (!tanggal_dari || !tanggal_sampai) {
						alert("Pastikan tanggal sudah dipilih.");
						return;
					}

					let data = [];

					// Header laporan
					data.push(["Laporan Rekap Keterlambatan Pegawai"]);
					data.push([`Tanggal: ${formatTanggal(tanggal_dari)} s/d ${formatTanggal(tanggal_sampai)}`]);
					data.push([]);
					data.push(["No", "Tanggal", "Nama Pegawai", "Jabatan", "Status", "Menit Terlambat"]);
					const tableRows = document.querySelectorAll("#data_presensi_keterlambatan_pegawai tbody tr");

					if (tableRows.length === 0) {
						alert("Tidak ada data untuk diekspor.");
						return;
					}

					let lastNo = '';
					let lastTanggal = '';
					let currentNo = '';
					let currentTanggal = '';
					let spanStartIndex = null;
					let currentRowIndex = data.length; // Start row index di Excel
					let mergeInstructions = [];

					tableRows.forEach((row, idx) => {
						const cells = Array.from(row.cells).map(cell => cell.textContent.trim());
						const isRowMerged = row.cells.length < 6;

						let finalRow = [];

						if (isRowMerged) {
							// Tambahkan nilai dari baris sebelumnya
							finalRow.push(lastNo);
							finalRow.push(lastTanggal);
							finalRow.push(...cells);
						} else {
							lastNo = cells[0];
							lastTanggal = cells[1];
							finalRow = cells;

							const isNewGroup = currentNo !== lastNo || currentTanggal !== lastTanggal;

							if (isNewGroup && spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {
								mergeInstructions.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
								mergeInstructions.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
							}

							if (isNewGroup) {
								spanStartIndex = currentRowIndex;
								currentNo = lastNo;
								currentTanggal = lastTanggal;
							}
						}

						data.push(finalRow);
						currentRowIndex++;

						if (idx === tableRows.length - 1 && spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {
							mergeInstructions.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
							mergeInstructions.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
						}
					});

					const worksheet = XLSX.utils.aoa_to_sheet(data);
					worksheet["!merges"] = mergeInstructions;

					worksheet["!cols"] = [
						{ wch: 5 },   // No
						{ wch: 20 },  // Tanggal
						{ wch: 25 },  // Nama Pegawai
						{ wch: 15 },  // Jabatan
						{ wch: 30 },  // Status
						{ wch: 30 },  //  Terlambat
						// { wch: 30 },  // Waktu
					];


					const range = XLSX.utils.decode_range(worksheet['!ref']);
					for (let R = range.s.r; R <= range.e.r; ++R) {
						for (let C = range.s.c; C <= range.e.c; ++C) {
							const cell_address = XLSX.utils.encode_cell({ r: R, c: C });
							const cell = worksheet[cell_address];
							if (cell) {
								cell.s = cell.s || {};
								cell.s.alignment = { wrapText: true, vertical: "top" };
							}
						}
					}


					const workbook = XLSX.utils.book_new();
					XLSX.utils.book_append_sheet(workbook, worksheet, "Rekap Keterlambatan Pegawai");
					XLSX.writeFile(workbook, `laporan_rekap_keterlambatan_pegawai_${formatTanggal(tanggal_dari)}_${formatTanggal(tanggal_sampai)}.xlsx`);


					$('#btn_print_laporan_excel').attr('disabled', false);
					$('#btn_print_laporan_excel').html('<i class="fa fa-file-excel me-1"></i> Excel');
				}, 1500);


			} else if (filter === 'bulan') {
				setTimeout(() => {
					const bulan = document.querySelector('select[name="filter_bulan"]')?.value || '';
					const tahun = document.querySelector('select[name="filter_tahun"]')?.value || '';



					let data = [];

					// Header laporan
					data.push(["Laporan Rekap Keterlambatan Pegawai"]);
					data.push([`Bulan: ${getNamaBulan(bulan)} ${tahun}`]);
					data.push([]);
					data.push(["No", "Tanggal", "Nama Pegawai", "Jabatan", "Status", "Menit Terlambat"]);

					const tableRows = document.querySelectorAll("#data_presensi_keterlambatan_pegawai tbody tr");

					if (tableRows.length === 0) {
						alert("Tidak ada data untuk diekspor.");
						return;
					}

					let lastNo = '';
					let lastTanggal = '';
					let currentNo = '';
					let currentTanggal = '';
					let spanStartIndex = null;
					let currentRowIndex = data.length; // Start row index di Excel
					let mergeInstructions = [];

					tableRows.forEach((row, idx) => {
						const cells = Array.from(row.cells).map(cell => cell.textContent.trim());
						const isRowMerged = row.cells.length < 6;

						let finalRow = [];

						if (isRowMerged) {
							// Tambahkan nilai dari baris sebelumnya
							finalRow.push(lastNo);
							finalRow.push(lastTanggal);
							finalRow.push(...cells);
						} else {
							lastNo = cells[0];
							lastTanggal = cells[1];
							finalRow = cells;

							const isNewGroup = currentNo !== lastNo || currentTanggal !== lastTanggal;

							if (isNewGroup && spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {
								mergeInstructions.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
								mergeInstructions.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
							}

							if (isNewGroup) {
								spanStartIndex = currentRowIndex;
								currentNo = lastNo;
								currentTanggal = lastTanggal;
							}
						}

						data.push(finalRow);
						currentRowIndex++;

						if (idx === tableRows.length - 1 && spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {
							mergeInstructions.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
							mergeInstructions.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
						}
					});

					const worksheet = XLSX.utils.aoa_to_sheet(data);
					worksheet["!merges"] = mergeInstructions;

					worksheet["!cols"] = [
						{ wch: 5 },   // No
						{ wch: 20 },  // Tanggal
						{ wch: 25 },  // Nama Pegawai
						{ wch: 15 },  // Jabatan
						{ wch: 30 },  // Status
						{ wch: 30 },  // Jam Terlambat
						// { wch: 30 },  // Waktu
					];


					const range = XLSX.utils.decode_range(worksheet['!ref']);
					for (let R = range.s.r; R <= range.e.r; ++R) {
						for (let C = range.s.c; C <= range.e.c; ++C) {
							const cell_address = XLSX.utils.encode_cell({ r: R, c: C });
							const cell = worksheet[cell_address];
							if (cell) {
								cell.s = cell.s || {};
								cell.s.alignment = { wrapText: true, vertical: "top" };
							}
						}
					}


					const workbook = XLSX.utils.book_new();
					XLSX.utils.book_append_sheet(workbook, worksheet, "Rekap Keterlambatan Pegawai");
					XLSX.writeFile(workbook, `laporan_rekap_keterlambatan_pegawai_bulan_${getNamaBulan(bulan)}_${tahun}.xlsx`);


					$('#btn_print_laporan_excel').attr('disabled', false);
					$('#btn_print_laporan_excel').html('<i class="fa fa-file-excel me-1"></i> Excel');
				}, 1500);
			} else {
				setTimeout(() => {
					const tahun = document.querySelector('select[name="single_filter_tahun"]')?.value || '';



					let data = [];

					// Header laporan
					data.push(["Laporan Rekap Keterlambatan Pegawai"]);
					data.push([`Tahun: ${tahun}`]);
					data.push([]);
					data.push(["No", "Tanggal", "Nama Pegawai", "Jabatan", "Status", "Menit Terlambat"]);

					const tableRows = document.querySelectorAll("#data_presensi_keterlambatan_pegawai tbody tr");

					if (tableRows.length === 0) {
						alert("Tidak ada data untuk diekspor.");
						return;
					}

					let lastNo = '';
					let lastTanggal = '';
					let currentNo = '';
					let currentTanggal = '';
					let spanStartIndex = null;
					let currentRowIndex = data.length; // Start row index di Excel
					let mergeInstructions = [];

					tableRows.forEach((row, idx) => {
						const cells = Array.from(row.cells).map(cell => cell.textContent.trim());
						const isRowMerged = row.cells.length < 6;

						let finalRow = [];

						if (isRowMerged) {
							// Tambahkan nilai dari baris sebelumnya
							finalRow.push(lastNo);
							finalRow.push(lastTanggal);
							finalRow.push(...cells);
						} else {
							lastNo = cells[0];
							lastTanggal = cells[1];
							finalRow = cells;

							const isNewGroup = currentNo !== lastNo || currentTanggal !== lastTanggal;

							if (isNewGroup && spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {
								mergeInstructions.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
								mergeInstructions.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
							}

							if (isNewGroup) {
								spanStartIndex = currentRowIndex;
								currentNo = lastNo;
								currentTanggal = lastTanggal;
							}
						}

						data.push(finalRow);
						currentRowIndex++;

						if (idx === tableRows.length - 1 && spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {
							mergeInstructions.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
							mergeInstructions.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
						}
					});

					const worksheet = XLSX.utils.aoa_to_sheet(data);
					worksheet["!merges"] = mergeInstructions;

					worksheet["!cols"] = [
						{ wch: 5 },   // No
						{ wch: 20 },  // Tanggal
						{ wch: 25 },  // Nama Pegawai
						{ wch: 15 },  // Jabatan
						{ wch: 30 },  // Status
						{ wch: 30 },  // Jam Terlambat
						// { wch: 30 },  // Waktu
					];


					const range = XLSX.utils.decode_range(worksheet['!ref']);
					for (let R = range.s.r; R <= range.e.r; ++R) {
						for (let C = range.s.c; C <= range.e.c; ++C) {
							const cell_address = XLSX.utils.encode_cell({ r: R, c: C });
							const cell = worksheet[cell_address];
							if (cell) {
								cell.s = cell.s || {};
								cell.s.alignment = { wrapText: true, vertical: "top" };
							}
						}
					}


					const workbook = XLSX.utils.book_new();
					XLSX.utils.book_append_sheet(workbook, worksheet, "Rekap Keterlambatan Pegawai");
					XLSX.writeFile(workbook, `laporan_rekap_keterlambatan_pegawai_tahun_${tahun}.xlsx`);


					$('#btn_print_laporan_excel').attr('disabled', false);
					$('#btn_print_laporan_excel').html('<i class="fa fa-file-excel me-1"></i> Excel');
				}, 1500);
			}
		} else if (cek_btn === 'presensi_per_pegawai') {
			const filter = document.querySelector('input[name="filter"]:checked')?.value;
			if (filter === 'tanggal') {
				setTimeout(() => {
					const tanggal_dari = document.querySelector('input[name="dari_tanggal"]')?.value || '';
					const tanggal_sampai = document.querySelector('input[name="sampai_tanggal"]')?.value || '';

					if (!tanggal_dari || !tanggal_sampai) {
						alert("Pastikan tanggal sudah dipilih.");
						return;
					}

					let data = [];
					const firstRow = document.querySelector("#data_presensi_per_pegawai tbody tr");
					// const namaPegawai = firstRow.cells[2]?.textContent?.trim() || 'Tidak Diketahui';
					// const jabatan = firstRow.cells[3]?.textContent?.trim() || 'Tidak Diketahui';
					const namaPegawai = $('#nama_per_pegawai').val().trim() || 'Tidak Diketahui';
					const jabatan = $('#pegawai_per_jabatan').val().trim() || 'Tidak Diketahui';
					// Header laporan
					data.push(["Laporan Presensi Per Pegawai"]);
					data.push([`Nama Pegawai : ${namaPegawai}`]);
					data.push([`Jabatan      : ${jabatan}`]);
					data.push([`Tanggal      : ${formatTanggal(tanggal_dari)} s/d ${formatTanggal(tanggal_sampai)}`]);
					data.push([]);
					data.push(["No", "Tanggal", "Jam Masuk", "Menit Terlambat", "Waktu", "Jam Pulang", "Status"]);
					// data.push([`Tanggal: ${formatTanggal(tanggal_dari)} s/d ${formatTanggal(tanggal_sampai)}`]);
					// data.push(["No", "Tanggal", "Nama Pegawai", "Jabatan", "Status", "Jam Terlambat", "Waktu", "Jam Pulang"]);
					const tableRows = document.querySelectorAll("#data_presensi_per_pegawai tbody tr");

					if (tableRows.length === 0) {
						alert("Tidak ada data untuk diekspor.");
						return;
					}

					let lastNo = '';
					let lastTanggal = '';
					let currentNo = '';
					let currentTanggal = '';
					let spanStartIndex = null;
					let currentRowIndex = data.length; // Start row index di Excel
					let mergeInstructions = [];

					tableRows.forEach((row, idx) => {
						// const cells = Array.from(row.cells).map(cell => cell.textContent.trim());
						let cells = Array.from(row.cells).map(cell => cell.textContent.trim());

						// Hapus Nama Pegawai & Jabatan
						cells.splice(2, 2);
						const isRowMerged = row.cells.length < 8;

						let finalRow = [];

						if (isRowMerged) {
							// Tambahkan nilai dari baris sebelumnya
							finalRow.push(lastNo);
							finalRow.push(lastTanggal);
							finalRow.push(...cells);
						} else {
							lastNo = cells[0];
							lastTanggal = cells[1];
							finalRow = cells;

							const isNewGroup = currentNo !== lastNo || currentTanggal !== lastTanggal;

							if (isNewGroup && spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {
								mergeInstructions.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
								mergeInstructions.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
							}

							if (isNewGroup) {
								spanStartIndex = currentRowIndex;
								currentNo = lastNo;
								currentTanggal = lastTanggal;
							}
						}

						data.push(finalRow);
						currentRowIndex++;

						if (idx === tableRows.length - 1 && spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {
							mergeInstructions.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
							mergeInstructions.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
						}
					});

					const worksheet = XLSX.utils.aoa_to_sheet(data);
					worksheet["!merges"] = mergeInstructions;

					worksheet["!cols"] = [
						{ wch: 5 },   // No
						{ wch: 20 },  // Tanggal
						// { wch: 25 },  // Nama Pegawai
						// { wch: 15 },  // Jabatan
						{ wch: 30 },  // Status
						{ wch: 30 },  // Jam Terlambat
						{ wch: 30 },  // Waktu
						{ wch: 30 },  // Jam Pulang
					];


					const range = XLSX.utils.decode_range(worksheet['!ref']);
					for (let R = range.s.r; R <= range.e.r; ++R) {
						for (let C = range.s.c; C <= range.e.c; ++C) {
							const cell_address = XLSX.utils.encode_cell({ r: R, c: C });
							const cell = worksheet[cell_address];
							if (cell) {
								cell.s = cell.s || {};
								cell.s.alignment = { wrapText: true, vertical: "top" };
							}
						}
					}


					const workbook = XLSX.utils.book_new();
					XLSX.utils.book_append_sheet(workbook, worksheet, "Laporan Presensi Per Pegawai");
					XLSX.writeFile(workbook, `laporan_presensi_per_pegawai_${namaPegawai}_${formatTanggal(tanggal_dari)}_${formatTanggal(tanggal_sampai)}.xlsx`);


					$('#btn_print_laporan_excel').attr('disabled', false);
					$('#btn_print_laporan_excel').html('<i class="fa fa-file-excel me-1"></i> Excel');
				}, 1500);


			} else if (filter === 'bulan') {
				const firstRow = document.querySelector("#data_presensi_per_pegawai tbody tr");
				setTimeout(() => {
					const bulan = document.querySelector('select[name="filter_bulan"]')?.value || '';
					const tahun = document.querySelector('select[name="filter_tahun"]')?.value || '';



					let data = [];

					// Header laporan
					data.push(["Laporan Presensi Per Pegawai"]);
					// const namaPegawai = firstRow.cells[2]?.textContent?.trim() || 'Tidak Diketahui';
					// const jabatan = firstRow.cells[3]?.textContent?.trim() || 'Tidak Diketahui';
					const namaPegawai = $('#nama_per_pegawai').val().trim() || 'Tidak Diketahui';
					const jabatan = $('#pegawai_per_jabatan').val().trim() || 'Tidak Diketahui';
					// data.push([`Bulan: ${getNamaBulan(bulan)} ${tahun}`]);
					// data.push([]);
					// data.push(["No", "Tanggal", "Nama Pegawai", "Jabatan", "Status", "Jam Terlambat", "Waktu", "Jam Pulang"]);
					data.push([`Nama Pegawai : ${namaPegawai}`]);
					data.push([`Jabatan      : ${jabatan}`]);
					data.push([`Bulan: ${getNamaBulan(bulan)} ${tahun}`]);
					data.push([]);
					data.push(["No", "Tanggal", "Jam Masuk", "Menit Terlambat", "Jam Pulang", "Status"]);
					const tableRows = document.querySelectorAll("#data_presensi_per_pegawai tbody tr");

					if (tableRows.length === 0) {
						alert("Tidak ada data untuk diekspor.");
						return;
					}

					let lastNo = '';
					let lastTanggal = '';
					let currentNo = '';
					let currentTanggal = '';
					let spanStartIndex = null;
					let currentRowIndex = data.length; // Start row index di Excel
					let mergeInstructions = [];

					tableRows.forEach((row, idx) => {
						// const cells = Array.from(row.cells).map(cell => cell.textContent.trim());
						let cells = Array.from(row.cells).map(cell => cell.textContent.trim());

						// Hapus Nama Pegawai & Jabatan
						cells.splice(2, 2);
						const isRowMerged = row.cells.length < 8;

						let finalRow = [];

						if (isRowMerged) {
							// Tambahkan nilai dari baris sebelumnya
							finalRow.push(lastNo);
							finalRow.push(lastTanggal);
							finalRow.push(...cells);
						} else {
							lastNo = cells[0];
							lastTanggal = cells[1];
							finalRow = cells;

							const isNewGroup = currentNo !== lastNo || currentTanggal !== lastTanggal;

							if (isNewGroup && spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {
								mergeInstructions.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
								mergeInstructions.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
							}

							if (isNewGroup) {
								spanStartIndex = currentRowIndex;
								currentNo = lastNo;
								currentTanggal = lastTanggal;
							}
						}

						data.push(finalRow);
						currentRowIndex++;

						if (idx === tableRows.length - 1 && spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {
							mergeInstructions.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
							mergeInstructions.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
						}
					});

					const worksheet = XLSX.utils.aoa_to_sheet(data);
					worksheet["!merges"] = mergeInstructions;

					worksheet["!cols"] = [
						{ wch: 5 },   // No
						{ wch: 20 },  // Tanggal
						// { wch: 25 },  // Nama Pegawai
						// { wch: 15 },  // Jabatan
						{ wch: 30 },  // Status
						{ wch: 30 },  // Jam Terlambat
						{ wch: 30 },  // Waktu
						{ wch: 30 },  // Jam Pulang
					];


					const range = XLSX.utils.decode_range(worksheet['!ref']);
					for (let R = range.s.r; R <= range.e.r; ++R) {
						for (let C = range.s.c; C <= range.e.c; ++C) {
							const cell_address = XLSX.utils.encode_cell({ r: R, c: C });
							const cell = worksheet[cell_address];
							if (cell) {
								cell.s = cell.s || {};
								cell.s.alignment = { wrapText: true, vertical: "top" };
							}
						}
					}


					const workbook = XLSX.utils.book_new();
					XLSX.utils.book_append_sheet(workbook, worksheet, "Laporan Presensi Per Pegawai");
					XLSX.writeFile(workbook, `laporan_presensi_per_pegawai_${namaPegawai}_bulan_${getNamaBulan(bulan)}_${tahun}.xlsx`);


					$('#btn_print_laporan_excel').attr('disabled', false);
					$('#btn_print_laporan_excel').html('<i class="fa fa-file-excel me-1"></i> Excel');
				}, 1500);
			} else {
				setTimeout(() => {
					const tahun = document.querySelector('select[name="single_filter_tahun"]')?.value || '';
					const firstRow = document.querySelector("#data_presensi_per_pegawai tbody tr");
					let data = [];
					// Header laporan
					data.push(["Laporan Presensi Per Pegawai"]);
					// const namaPegawai = firstRow.cells[2]?.textContent?.trim() || 'Tidak Diketahui';
					// const jabatan = firstRow.cells[3]?.textContent?.trim() || 'Tidak Diketahui';
					const namaPegawai = $('#nama_per_pegawai').val().trim() || 'Tidak Diketahui';
					const jabatan = $('#pegawai_per_jabatan').val().trim() || 'Tidak Diketahui';
					data.push([`Nama Pegawai : ${namaPegawai}`]);
					data.push([`Jabatan      : ${jabatan}`]);
					data.push([`Tahun: ${tahun}`]);
					data.push([]);
					data.push(["No", "Tanggal", "Jam Masuk", "Menit Terlambat", "Jam Pulang", "Status"]);
					// data.push([]);
					// data.push(["No", "Tanggal", "Nama Pegawai", "Jabatan", "Status", "Jam Terlambat", "Waktu", "Jam Pulang"]);

					const tableRows = document.querySelectorAll("#data_presensi_per_pegawai tbody tr");

					if (tableRows.length === 0) {
						alert("Tidak ada data untuk diekspor.");
						return;
					}

					let lastNo = '';
					let lastTanggal = '';
					let currentNo = '';
					let currentTanggal = '';
					let spanStartIndex = null;
					let currentRowIndex = data.length; // Start row index di Excel
					let mergeInstructions = [];

					tableRows.forEach((row, idx) => {
						// const cells = Array.from(row.cells).map(cell => cell.textContent.trim());
						let cells = Array.from(row.cells).map(cell => cell.textContent.trim());
						// Hapus Nama Pegawai & Jabatan
						cells.splice(2, 2);
						const isRowMerged = row.cells.length < 7;

						let finalRow = [];

						if (isRowMerged) {
							// Tambahkan nilai dari baris sebelumnya
							finalRow.push(lastNo);
							finalRow.push(lastTanggal);
							finalRow.push(...cells);
						} else {
							lastNo = cells[0];
							lastTanggal = cells[1];
							finalRow = cells;

							const isNewGroup = currentNo !== lastNo || currentTanggal !== lastTanggal;

							if (isNewGroup && spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {
								mergeInstructions.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
								mergeInstructions.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
							}

							if (isNewGroup) {
								spanStartIndex = currentRowIndex;
								currentNo = lastNo;
								currentTanggal = lastTanggal;
							}
						}

						data.push(finalRow);
						currentRowIndex++;

						if (idx === tableRows.length - 1 && spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {
							mergeInstructions.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
							mergeInstructions.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
						}
					});

					const worksheet = XLSX.utils.aoa_to_sheet(data);
					worksheet["!merges"] = mergeInstructions;

					worksheet["!cols"] = [
						{ wch: 5 },   // No
						{ wch: 20 },  // Tanggal
						// { wch: 25 },  // Nama Pegawai
						// { wch: 15 },  // Jabatan
						{ wch: 30 },  // Status
						{ wch: 30 },  // Jam Terlambat
						{ wch: 30 },  // Waktu
						{ wch: 30 },  // Jam Pulang
					];


					const range = XLSX.utils.decode_range(worksheet['!ref']);
					for (let R = range.s.r; R <= range.e.r; ++R) {
						for (let C = range.s.c; C <= range.e.c; ++C) {
							const cell_address = XLSX.utils.encode_cell({ r: R, c: C });
							const cell = worksheet[cell_address];
							if (cell) {
								cell.s = cell.s || {};
								cell.s.alignment = { wrapText: true, vertical: "top" };
							}
						}
					}


					const workbook = XLSX.utils.book_new();
					XLSX.utils.book_append_sheet(workbook, worksheet, "Laporan Presensi Per Pegawai");
					XLSX.writeFile(workbook, `laporan_presensi_per_pegawai_${namaPegawai}_tahun_${tahun}.xlsx`);


					$('#btn_print_laporan_excel').attr('disabled', false);
					$('#btn_print_laporan_excel').html('<i class="fa fa-file-excel me-1"></i> Excel');
				}, 1500);
			}
		} else if (cek_btn === 'resume_tanggal_kegiatan' || cek_btn === 'Karyawan') {
			const filter = document.querySelector('input[name="filter"]:checked')?.value;

			// Helper buat set header laporan & nama file
			let headerTitle = "Resume Tanggal Jurnal Kegiatan - Belum Diisi";
			let subTitle = "";
			let fileName = "resume_tanggal_kegiatan_belum_diisi";

			if (filter === 'tanggal') {
				const tanggal_dari = document.querySelector('input[name="dari_tanggal"]')?.value || '';
				const tanggal_sampai = document.querySelector('input[name="sampai_tanggal"]')?.value || '';
				if (!tanggal_dari || !tanggal_sampai) {
					alert("Pastikan tanggal sudah dipilih.");
					return;
				}
				subTitle = `Tanggal: ${formatTanggal(tanggal_dari)} s/d ${formatTanggal(tanggal_sampai)}`;
				fileName += `_${formatTanggal(tanggal_dari)}_${formatTanggal(tanggal_sampai)}`;
			} else if (filter === 'bulan') {
				const bulan = document.querySelector('select[name="filter_bulan"]')?.value || '';
				const tahun = document.querySelector('select[name="filter_tahun"]')?.value || '';
				if (!bulan || !tahun) {
					alert("Pastikan bulan dan tahun dipilih.");
					return;
				}
				subTitle = `Bulan: ${getNamaBulan(bulan)} ${tahun}`;
				fileName += `_bulan_${getNamaBulan(bulan)}_${tahun}`;
			} else {
				const tahun = document.querySelector('select[name="single_filter_tahun"]')?.value || '';
				if (!tahun) {
					alert("Pastikan tahun dipilih.");
					return;
				}
				subTitle = `Tahun: ${tahun}`;
				fileName += `_tahun_${tahun}`;
			}

			setTimeout(() => {
				const tableRows = document.querySelectorAll("#data_resume_tanggal_kegiatan tbody tr");
				if (!tableRows.length) {
					alert("Tidak ada data untuk diekspor.");
					return;
				}

				let data = [];
				// Header laporan
				data.push([headerTitle]);
				if (subTitle) data.push([subTitle]);
				data.push([]);
				data.push(["No", "Nama Pegawai", "Tanggal Belum Diisi", "Semester", "Periode"]);

				// Variabel untuk tracking merge
				let lastNo = "";
				let lastNama = "";
				let lastSemester = "";
				let lastPeriode = "";

				let currentNo = "";
				let currentNama = "";
				let currentSemester = "";
				let currentPeriode = "";

				let spanStartIndex = null;              // index baris awal group (di worksheet)
				let currentRowIndex = data.length;      // row index Excel saat ini (0-based pada array data)
				let mergeInstructions = [];

				// Helper escape (kalau mau aman dari karakter spesial)
				const getText = (cell) => (cell?.textContent || "").trim();

				tableRows.forEach((row, idx) => {
					// Untuk tabel ini total kolom = 5 pada baris pertama group:
					// [No, Nama, Tanggal, Semester, Periode]
					// Baris berikutnya untuk group yang sama biasanya hanya kolom Tanggal → cells.length < 5
					const cells = Array.from(row.cells).map(td => getText(td));
					const isRowMerged = row.cells.length < 5;

					let finalRow = [];

					if (isRowMerged) {
						// Baris kelanjutan dari group yang sama → pakai lastNo, lastNama, lastSemester, lastPeriode
						finalRow.push(lastNo);
						finalRow.push(lastNama);
						finalRow.push(cells[0] || ""); // kolom Tanggal
						finalRow.push(lastSemester);
						finalRow.push(lastPeriode);
					} else {
						// Baris pertama untuk group baru
						lastNo = cells[0] || "";
						lastNama = cells[1] || "";
						lastSemester = cells[3] || "";
						lastPeriode = cells[4] || "";

						finalRow = cells; // ["No","Nama","Tanggal","Semester","Periode"]

						const isNewGroup =
							currentNo !== lastNo ||
							currentNama !== lastNama ||
							currentSemester !== lastSemester ||
							currentPeriode !== lastPeriode;

						// Tutup merge group sebelumnya (kalau panjangnya > 1 baris)
						if (isNewGroup && spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {
							// Merge kolom No (c=0), Nama (c=1), Semester (c=3), Periode (c=4)
							mergeInstructions.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
							mergeInstructions.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
							mergeInstructions.push({ s: { r: spanStartIndex, c: 3 }, e: { r: currentRowIndex - 1, c: 3 } });
							mergeInstructions.push({ s: { r: spanStartIndex, c: 4 }, e: { r: currentRowIndex - 1, c: 4 } });
						}

						if (isNewGroup) {
							spanStartIndex = currentRowIndex;
							currentNo = lastNo;
							currentNama = lastNama;
							currentSemester = lastSemester;
							currentPeriode = lastPeriode;
						}
					}

					data.push(finalRow);
					currentRowIndex++;

					// Jika ini baris terakhir, tutup merge terakhir jika perlu
					if (idx === tableRows.length - 1 && spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {
						mergeInstructions.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
						mergeInstructions.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
						mergeInstructions.push({ s: { r: spanStartIndex, c: 3 }, e: { r: currentRowIndex - 1, c: 3 } });
						mergeInstructions.push({ s: { r: spanStartIndex, c: 4 }, e: { r: currentRowIndex - 1, c: 4 } });
					}
				});

				const worksheet = XLSX.utils.aoa_to_sheet(data);
				worksheet["!merges"] = mergeInstructions;

				// Set lebar kolom
				worksheet["!cols"] = [
					{ wch: 5 },   // No
					{ wch: 28 },  // Nama Pegawai
					{ wch: 22 },  // Tanggal Belum Diisi
					{ wch: 14 },  // Semester
					{ wch: 16 },  // Periode
				];

				// Wrap text & align top
				const range = XLSX.utils.decode_range(worksheet['!ref']);
				for (let R = range.s.r; R <= range.e.r; ++R) {
					for (let C = range.s.c; C <= range.e.c; ++C) {
						const cell_address = XLSX.utils.encode_cell({ r: R, c: C });
						const cell = worksheet[cell_address];
						if (cell) {
							cell.s = cell.s || {};
							cell.s.alignment = { wrapText: true, vertical: "top" };
						}
					}
				}

				const workbook = XLSX.utils.book_new();
				XLSX.utils.book_append_sheet(workbook, worksheet, "Resume Belum Diisi");
				XLSX.writeFile(workbook, `${fileName}.xlsx`);


				$('#btn_print_laporan_excel').attr('disabled', false).html('<i class="fa fa-file-excel me-1"></i> Excel');
			}, 500);
		} else if (cek_btn == 'Guru') {
			const filter = document.querySelector('input[name="filter"]:checked')?.value;

			// Header & nama file
			let headerTitle = "Resume Tanggal Jurnal Guru - Belum Diisi";
			let subTitle = "";
			let fileName = "resume_tanggal_jurnal_guru_belum_diisi";

			if (filter === 'tanggal') {
				const tanggal_dari = document.querySelector('input[name="dari_tanggal"]')?.value || '';
				const tanggal_sampai = document.querySelector('input[name="sampai_tanggal"]')?.value || '';
				if (!tanggal_dari || !tanggal_sampai) return alert("Pastikan tanggal sudah dipilih.");
				subTitle = `Tanggal: ${formatTanggal(tanggal_dari)} s/d ${formatTanggal(tanggal_sampai)}`;
				fileName += `_${formatTanggal(tanggal_dari)}_${formatTanggal(tanggal_sampai)}`;
			} else if (filter === 'bulan') {
				const bulan = document.querySelector('select[name="filter_bulan"]')?.value || '';
				const tahun = document.querySelector('select[name="filter_tahun"]')?.value || '';
				if (!bulan || !tahun) return alert("Pastikan bulan dan tahun dipilih.");
				subTitle = `Bulan: ${getNamaBulan(bulan)} ${tahun}`;
				fileName += `_bulan_${getNamaBulan(bulan)}_${tahun}`;
			} else {
				const tahun = document.querySelector('select[name="single_filter_tahun"]')?.value || '';
				if (!tahun) return alert("Pastikan tahun dipilih.");
				subTitle = `Tahun: ${tahun}`;
				fileName += `_tahun_${tahun}`;
			}

			setTimeout(() => {
				// TABEL dengan thead: [No, Nama, Kelas, Mapel, Tanggal, Semester, Periode]
				const tableRows = document.querySelectorAll("#data_resume_tanggal_guru tbody tr");
				if (!tableRows.length) return alert("Tidak ada data untuk diekspor.");

				const txt = (td) => (td?.textContent || '').trim();

				const data = [];
				data.push([headerTitle]);
				if (subTitle) data.push([subTitle]);
				data.push([]);
				data.push(["No", "Nama Guru", "Kelas", "Mapel", "Tanggal Belum Diisi", "Semester", "Periode"]);

				// Merge hanya untuk: No(0), Nama(1), Semester(5), Periode(6)
				let lastNo = "", lastNama = "", lastSemester = "", lastPeriode = "";
				let currentNo = "", currentNama = "", currentSemester = "", currentPeriode = "";
				let spanStartIndex = null;
				let currentRowIndex = data.length;
				const merges = [];

				tableRows.forEach((row, idx) => {
					const cells = Array.from(row.cells).map(txt);
					// Baris awal grup = 7 sel (No, Nama, Kelas, Mapel, Tanggal, Semester, Periode)
					// Baris lanjutan = 3 sel (Kelas, Mapel, Tanggal) karena No, Nama, Semester, Periode di-rowspan di HTML
					const isContinuation = row.cells.length < 7;

					let out = [];

					if (isContinuation) {
						const kelas = cells[0] || "";
						const mapel = cells[1] || "";
						const tanggal = cells[2] || "";
						out = [lastNo, lastNama, kelas, mapel, tanggal, lastSemester, lastPeriode];
					} else {
						lastNo = cells[0] || "";
						lastNama = cells[1] || "";
						const kelas = cells[2] || "";
						const mapel = cells[3] || "";
						const tanggal = cells[4] || "";
						lastSemester = cells[5] || "";
						lastPeriode = cells[6] || "";

						out = [lastNo, lastNama, kelas, mapel, tanggal, lastSemester, lastPeriode];

						const isNewGroup =
							currentNo !== lastNo ||
							currentNama !== lastNama ||
							currentSemester !== lastSemester ||
							currentPeriode !== lastPeriode;

						// Tutup merge grup sebelumnya (kalau ada >1 baris)
						if (isNewGroup && spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {
							merges.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } }); // No
							merges.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } }); // Nama
							merges.push({ s: { r: spanStartIndex, c: 5 }, e: { r: currentRowIndex - 1, c: 5 } }); // Semester
							merges.push({ s: { r: spanStartIndex, c: 6 }, e: { r: currentRowIndex - 1, c: 6 } }); // Periode
						}

						if (isNewGroup) {
							spanStartIndex = currentRowIndex;
							currentNo = lastNo;
							currentNama = lastNama;
							currentSemester = lastSemester;
							currentPeriode = lastPeriode;
						}
					}

					data.push(out);
					currentRowIndex++;

					// Tutup grup terakhir bila perlu
					if (idx === tableRows.length - 1 && spanStartIndex !== null && currentRowIndex > spanStartIndex + 1) {
						merges.push({ s: { r: spanStartIndex, c: 0 }, e: { r: currentRowIndex - 1, c: 0 } });
						merges.push({ s: { r: spanStartIndex, c: 1 }, e: { r: currentRowIndex - 1, c: 1 } });
						merges.push({ s: { r: spanStartIndex, c: 5 }, e: { r: currentRowIndex - 1, c: 5 } });
						merges.push({ s: { r: spanStartIndex, c: 6 }, e: { r: currentRowIndex - 1, c: 6 } });
					}
				});

				const ws = XLSX.utils.aoa_to_sheet(data);
				ws["!merges"] = merges;

				ws["!cols"] = [
					{ wch: 5 },   // No
					{ wch: 26 },  // Nama
					{ wch: 22 },  // Kelas
					{ wch: 18 },  // Mapel
					{ wch: 22 },  // Tanggal
					{ wch: 12 },  // Semester
					{ wch: 14 },  // Periode
				];

				// Wrap & align
				const range = XLSX.utils.decode_range(ws['!ref']);
				for (let R = range.s.r; R <= range.e.r; ++R) {
					for (let C = range.s.c; C <= range.e.c; ++C) {
						const addr = XLSX.utils.encode_cell({ r: R, c: C });
						const cell = ws[addr];
						if (cell) {
							cell.s = cell.s || {};
							cell.s.alignment = { wrapText: true, vertical: "top" };
						}
					}
				}

				const wb = XLSX.utils.book_new();
				XLSX.utils.book_append_sheet(wb, ws, "Resume Belum Diisi");
				XLSX.writeFile(wb, `${fileName}.xlsx`);

				$('#btn_print_laporan_excel')
					.attr('disabled', false)
					.html('<i class="fa fa-file-excel me-1"></i> Excel');
			}, 400);
		}

	});

	function formatTanggal(tanggal) {
		if (!tanggal) return '';
		const parts = tanggal.split('-');
		return `${parts[2]}-${parts[1]}-${parts[0]}`;
	}

	function getNamaBulan(bulan) {
		const namaBulan = [
			"Januari", "Februari", "Maret", "April", "Mei", "Juni",
			"Juli", "Agustus", "September", "Oktober", "November", "Desember"
		];


		const index = parseInt(bulan, 10) - 1;

		return namaBulan[index] || "";
	}

	function hitungSelisihHariDMY(tanggalStr, tanggalInputStr) {
		const tanggal = parseDMYToDate(tanggalStr);
		const tanggalInput = parseDMYToDate(tanggalInputStr);

		const selisihMs = tanggalInput - tanggal;
		const selisihHari = Math.round(selisihMs / (1000 * 60 * 60 * 24));

		const selisih = Math.max(0, selisihHari);

		return selisih <= 0 ? '' : ` (${selisih} hari)`;
	}

	function parseDMYToDate(dmyStr) {
		const [day, month, year] = dmyStr.split('-').map(Number);
		return new Date(year, month - 1, day);
	}

	function getPegawaiInfo() {
		const sel = document.querySelector('select[name="id_pegawai"]');
		const val = sel?.value || '';
		const isSemua = !val; // value "" = Semua Pegawai
		const opt = sel?.options[sel.selectedIndex];
		const nama = isSemua ? 'SEMUA PEGAWAI' : (opt?.getAttribute('data-label') || '-');
		const jab = isSemua ? '-' : (opt?.getAttribute('data-jabatan') || '-');
		return { isSemua, nama, jab };
	}
</script>